<?php
include_once('connection.php');
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}
header('Content-type: application/json');
$msg = "No data received.";
$ratings = [];
try { 
$post = file_get_contents('php://input');
$d = json_decode($post,true);
$msg = "No data received.";
 if(isset($d['selectedRating'])){

	$errors = [];

	if(!preg_match("/^[0-9]{1}$/i", $d['selectedRating'])){
		$errors[]="Rating may only contain one digit.";
	}


	$q = $db->prepare('SELECT * FROM `rating` where user_id = :user_id ');
	$q->bindParam(':user_id', $_SESSION['login_user']['id']);
	$q->execute();
	$q->setFetchMode(PDO::FETCH_ASSOC);
	$previous_ratings = $q->fetchAll();

	$q = $db->prepare('SELECT * FROM `booking` where user_id = :user_id and kashta_id = :kashta_id');
	$q->bindParam(':user_id', $_SESSION['login_user']['id']);
	$q->bindParam(':kashta_id', $d['kashta_id']);
	$q->execute();
	$q->setFetchMode(PDO::FETCH_ASSOC);
	$previous_bookings = $q->fetchAll();

	if(count($previous_ratings) >= count($previous_bookings)){
		$errors[]="You have exceeded the number of allowed ratings for this kashta.";
	}

	if(count($errors)){
		$msg = "";
		foreach ($errors as $key => $value) {
			$msg.= "$value\n";
		}
		http_response_code(500);
	}else{
		$db->beginTransaction();

		$stmt = $db->prepare("
		INSERT INTO `rating` 
		(`kashta_id`,	`user_id`,	`stars`) VALUES 
		(:kashta_id,	:user_id ,	:stars);");

		$stmt->bindParam(':kashta_id',$d['kashta_id']);
		$stmt->bindParam(':user_id', $_SESSION['login_user']['id']);
		$stmt->bindParam(':stars',$d['selectedRating']);
		
		$stmt->execute();
		$db->commit();
		$msg = "Rating added.";

		$q = $db->prepare('select rating.*, users.username as `name`, users.profile_image as `img` from rating left join users on users.id = rating.user_id where kashta_id = :kashta_id ORDER BY `rating`.`id` DESC');
		$q->bindParam(':kashta_id', $d['kashta_id']);
		$q->execute();

		$q->setFetchMode(PDO::FETCH_ASSOC);
		$ratings = $q->fetchAll();
	}
}
} catch(Exception $e) {
	http_response_code(500);
	$msg = $e->getMessage().$e->getTraceAsString();
}
echo json_encode(array("message"=>$msg,"ratings"=>$ratings));