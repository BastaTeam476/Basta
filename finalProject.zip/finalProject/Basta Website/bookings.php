<html>


<?php include 'header.php'; ?>

<head>
	<title> Login </title>
</head>

<body>
	<main>
		<div class="container-signup">
			<h1 style="color:#776559">
				Bookings
			</h1>
			<?php
			$q = $db->prepare('
			select booking.*, kashta.name, kashta.description, kashta.price 
			from booking left join kashta on kashta.id = booking.kashta_id 
			where user_id = :user_id');
			$q->bindParam(':user_id', $_SESSION['login_user']['id']);
			$q->execute();
	
			$q->setFetchMode(PDO::FETCH_ASSOC);
			$bookings = $q->fetchAll();

			foreach ($bookings as $i => $booking) {
				
				$q = $db->prepare('select kashta_services.* from booking_services left join kashta_services on kashta_services.id = booking_services.service_id where booking_services.booking_id = :booking_id');
				$q->bindParam(':booking_id', $booking['id']);
				$q->execute();
		
				$q->setFetchMode(PDO::FETCH_ASSOC);
				$services = $q->fetchAll();

				$total_price = $booking['price'];
				$servicesPicked = [];
				foreach ($services as $key => $service) {
					$total_price += $service['added_price'];
					$servicesPicked[]=$service['id'];
				}
				$q = $db->prepare('select * from kashta_images where kashta_id = :id');
				$q->bindParam(':id', $booking['kashta_id']);
				$q->execute();
		
				$q->setFetchMode(PDO::FETCH_ASSOC);
				$kashta_images = $q->fetchAll();
			?>



			<div class="booking-row">
				<div>
					<h3>
						<?=$booking['name']?>
					</h3>
					<p>
						<?=$booking['description']?>
					</p>
					<p>
						Price : <?=$total_price?> BD
					</p>
					<p>
						Booking Date : <?=$booking['date']?>
					</p>
					<form action="view-booking.php?booking_id=<?=$booking['id']?>" method="POST">
						<input style="color:white;" class="btn btn-primary w-90 stretched-link" value="View Booking" name="subreserve"
							type="submit" />
						<input type="hidden" name="date" value="<?=$booking['date']?>">
						<input type="hidden" name="timing" value="<?=$booking['timing']?>">
						<input type="hidden" name="location" value="<?=$booking['location']?>">
						<input type="hidden" name="place" value="<?=$booking['place']?>">
						<?php foreach ($servicesPicked as $key => $serviceID) { ?>
						<input type="hidden" name="service_ids[]" value="<?=$serviceID?>">
						<?php } ?>
					</form>
				</div>
				<div style="width: 200px;">
					<div id="<?="carousel".$booking['kashta_id']?>" class="carousel slide" data-ride="carousel"
						data-interval="<?=($i*1000)+2000?>">
						<ol class="carousel-indicators">
							<?php foreach ($kashta_images as $img_index => $image) { ?>
							<li data-target="#<?="carousel".$booking['kashta_id']?>" data-slide-to="<?=$img_index?>"
								<?=$img_index==0?"class='active'":""?>></li>
							<?php } ?>
						</ol>
						<div class="carousel-inner">

							<?php foreach ($kashta_images as $img_index => $image) { ?>
							<div class="carousel-item <?=$img_index==0?"active":""?>">

								<div class="kashta-image w-100" data-toggle="modal" data-target="#expanded-images"
									onclick="initImageModal(event)"
									data-imageurl="Kashta Pics/<?=$booking['kashta_id']."/".$image['filename']?>"
									style="cursor: pointer; background-image:url('Kashta Pics/<?=$booking['kashta_id']."/".$image['filename']?>')">
								</div>
							</div>
							<?php } ?>
						</div>
						<a class="carousel-control-prev" href="#<?="carousel".$booking['kashta_id']?>" role="button"
							data-slide="prev">
							<span class="carousel-control-prev-icon" aria-hidden="true"></span>
							<span class="sr-only">Previous</span>
						</a>
						<a class="carousel-control-next" href="#<?="carousel".$booking['kashta_id']?>" role="button"
							data-slide="next">
							<span class="carousel-control-next-icon" aria-hidden="true"></span>
							<span class="sr-only">Next</span>
						</a>
					</div>
				</div>
			</div>
			<br />
			<?php } ?>


		</div>

		<div class="modal fade" id="expanded-images" tabindex="-1" role="dialog" aria-labelledby="expanded-imagesLabel"
			aria-hidden="true">
			<div class="modal-dialog" role="document">
				<div class="modal-content">
					<div class="modal-header">
						<h5 class="modal-title" id="expanded-imagesLabel">
							Image
						</h5>
						<button type="button" class="close" data-dismiss="modal" aria-label="Close">
							<span aria-hidden="true">&times;</span>
						</button>
					</div>
					<div class="modal-body">
						<div class="full-image"></div>
					</div>
					<div class="modal-footer">
						<button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>

					</div>
				</div>
			</div>
		</div>
	</main>


</body>
<script src="view.js"></script>

<?php include 'footer.php'; ?>

</html>