<?php include 'header.php';?>
<!DOCTYPE html>
<html lang="en">

<head>
	<meta charset="UTF-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<title>Document</title>
	<link rel="stylesheet" href="S_1.css">
</head>

<body>
	<main>
		<div class="hero">
			<div class="herobox1">
				<img src="logo1r.png" width=300 height=auto>
			</div>
			<div class="herobox2">
				<h3>Contact Us:-</h3><br/>
				
                    <table>
                    <h5 style='font-weight:bold; color:#776559'>You can contact us at:-</h5>
                    <tr><td>33334444</td></tr>
                    <tr><td>12345765</td></tr>
                    <tr><td>09876544</td></tr>
                    <tr><td>basta111@bastabasta.com</td></tr>
                    </table>
                
				</p>
			</div>
		</div>
	</main>

</body>
<?php include 'footer.php';?>

</html>