<footer>
	<div class="footer_link">
		<a href="aboutus.php">About us </a>
		<a href="terms.php"> Terms & conditions </a>
		<a href="privacy.php"> Privacy and Conditions </a>
		<a href="joinus.php"> Join us </a>
		<a href="contactus.php"> Contact us </a>
	</div>
	<script>
	$(function() {
		$('[data-toggle="tooltip"]').tooltip()
	})
	</script>
</footer>