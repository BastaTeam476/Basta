<?php include 'login.guard.php' ?>

<?php include 'header.php';?>
<?php
if(isset($_GET['kashta_id'])){
$q = $db->prepare('select * from kashta where id = :id');
$q->bindParam(':id', $_GET['kashta_id']);
$q->execute();

$q->setFetchMode(PDO::FETCH_ASSOC);
$kashta = $q->fetch();

$q = $db->prepare('select * from kashta_images where kashta_id = :id');
$q->bindParam(':id', $kashta['id']);
$q->execute();

$q->setFetchMode(PDO::FETCH_ASSOC);
$kashta_images = $q->fetchAll();
}
 ?>
<!DOCTYPE html>
<html lang="en">

<head>
	<meta charset="UTF-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/css/bootstrap.min.css"
		integrity="sha384-xOolHFLEh07PJGoPkLv1IbcEPTNtaed2xpHsD9ESMhqIYd0nLMwNLD69Npy4HI+N" crossorigin="anonymous">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<link rel="stylesheet" href="S_1.css">

	<title>Document</title>
</head>

<body>
	<div class="card" style="width:70%">


		<div id="<?="carousel".$kashta['id']?>" class="carousel slide" data-ride="carousel" data-interval="<?=2000?>">
			<ol class="carousel-indicators">
				<?php foreach ($kashta_images as $img_index => $image) { ?>
				<li data-target="#<?="carousel".$kashta['id']?>" data-slide-to="<?=$img_index?>"
					<?=$img_index==0?"class='active'":""?>></li>
				<?php } ?>
			</ol>
			<div class="carousel-inner">
				<div class="capacityrange">
					<i class="fa fa-user"></i> <?=$kashta['min_capacity']?> -
					<?=$kashta['max_capacity']?>
				</div>
				<?php foreach ($kashta_images as $img_index => $image) { ?>
				<div class="carousel-item <?=$img_index==0?"active":""?>">

					<div class="kashta-image w-100" data-toggle="modal" data-target="#expanded-images"
						onclick="initImageModal(event)"
						data-imageurl="Kashta Pics/<?=$kashta['id']."/".$image['filename']?>"
						style="cursor: pointer; background-image:url('Kashta Pics/<?=$kashta['id']."/".$image['filename']?>')">
					</div>
				</div>
				<?php } ?>
			</div>
			<a class="carousel-control-prev" href="#<?="carousel".$kashta['id']?>" role="button" data-slide="prev">
				<span class="carousel-control-prev-icon" aria-hidden="true"></span>
				<span class="sr-only">Previous</span>
			</a>
			<a class="carousel-control-next" href="#<?="carousel".$kashta['id']?>" role="button" data-slide="next">
				<span class="carousel-control-next-icon" aria-hidden="true"></span>
				<span class="sr-only">Next</span>
			</a>
		</div>

		<div class="basta-info">
			<p>
				<b class="h2" style="color:#776559"><?=$kashta['name']?></b><br>
			</p>

			<h2 class="newlyfont myh3" >Price:</h2>
			<p> <?=$kashta['price']?> BD</p>

			<h2 class="newlyfont myh3">Description:</h2>
			<p> <?=$kashta['description']?></p>

			<h2 class="newlyfont myh3">Rating :</h2>
			<div class="stars-container">

				<?php
							$q = $db->prepare('select rating.*, users.username as `name`, users.profile_image as `img` from rating left join users on users.id = rating.user_id where kashta_id = :kashta_id ORDER BY `rating`.`id` DESC');
							$q->bindParam(':kashta_id', $kashta['id']);
							$q->execute();
					
							$q->setFetchMode(PDO::FETCH_ASSOC);
							$ratings = $q->fetchAll();

							$rate_sum = 0;

							foreach ($ratings as $key => $rate) {
								$rate_sum += $rate['stars'];
							}
							$average = $rate_sum>=1?round(($rate_sum / count($ratings)), 1):0;
							$averagefloored = floor($average);
							
				for ($i=0; $i < 5; $i++) { 
					?>
				<div class="starx <?=$averagefloored >= ($i+1)?"hovereffect":""?>">
					<i class="fa fa-star"></i>
				</div>
				<?php
				}
			?>
				<div>
					(<?=$average?>)
				</div>
			</div>
			<div>
				<br />
				<?php
	$q = $db->prepare('select * from booking where user_id = :user_id and kashta_id = :kashta_id and date < CURDATE()');
	$q->bindParam(':user_id', $_SESSION['login_user']['id']);
	$q->bindParam(':kashta_id', $kashta['id']);
	$q->execute();

	$q->setFetchMode(PDO::FETCH_ASSOC);
	$bookings = $q->fetchAll();
?>
				<?php
		

		if(count($bookings)){
			
		?>
				<button class="btn btn-primary" data-toggle="modal" data-target="#exampleModal">Rate</button>
				<?php
		

				}			
		?>
			</div><br/>

			<h2 class="newlyfont myh3">Comments:</h2>

			<?php
		

			if(count($bookings)){
				
			?>
			<input type="hidden" name="kashta_id" value="<?=$kashta['id']?>">
			<textarea cols="45" name="comment" id="comment"></textarea>
            <textarea cols="20" name="comment" id="comment2"></textarea>
			<br>
			<br>
			<button class="btn btn-primary" onclick="addComment()">Submit</button>


			<?php } 
			
			
		$q = $db->prepare('select comments.*, users.username as `name`, users.profile_image as `img` from comments left join users on users.id = comments.user_id where kashta_id = :kashta_id ORDER BY `comments`.`id` DESC');
		$q->bindParam(':kashta_id', $kashta['id']);
		$q->execute();

		$q->setFetchMode(PDO::FETCH_ASSOC);
		$comments = $q->fetchAll();
			?>
			<div class="comment-section">

				<?php foreach ($comments as $key => $comment) { ?>
				<div class="commentblock">
					<p>
						<?=$comment['description']?>
					</p>
					<div class="time-block">
						<div class="user-p">
							<div>
								<div class="mini-profilepic"
									style="background-image:url('<?php echo "ProfileImages/".$comment['img'] ?>')">

								</div>
							</div>
							<div id="abcde">
								<?=$comment['name']?>
							</div>
						</div>
						<div>
							<b id="xyz"><?=$comment['created_at']?></b>
						</div>
					</div>
				</div>
				<?php } ?>
			</div>


		</div>

		<div class="reservbotton">
			<a href="reservation.php?kashta_id=<?=$kashta['id']?>"><button type="" class="btn btn-primary">Reserve
					now</button></a>
			<!-- <a href="comment.php"><button type="" class="btn btn-primary">View Comments</button></a> -->
		</div>

	</div>
	<!-- Option 2: Separate Popper and Bootstrap JS -->
	<!--
    <script src="https://cdn.jsdelivr.net/npm/jquery@3.5.1/dist/jquery.slim.min.js" integrity="sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBnE+IbbVYUew+OrCXaRkfj" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.1/dist/umd/popper.min.js" integrity="sha384-9/reFTGAW83EW2RDu2S0VKaIzap3H66lZH81PoYlFhbGU+6BZp6G7niu735Sk7lN" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/js/bootstrap.min.js" integrity="sha384-+sLIOodYLS7CIrQpBjl+C7nPvqq+FbNUBDunl/OZv93DB7Ln/533i8e/mZXLi/P+" crossorigin="anonymous"></script>
    -->
	<!-- Modal -->
	<div class="modal fade" id="exampleModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel"
		aria-hidden="true">
		<div class="modal-dialog" role="document">
			<div class="modal-content">
				<div class="modal-header">
					<h5 class="modal-title" id="exampleModalLabel">
						Add Rating
					</h5>
					<button type="button" class="close" data-dismiss="modal" aria-label="Close">
						<span aria-hidden="true">&times;</span>
					</button>
				</div>
				<div class="modal-body">
					<input id="selectStars" hidden />
					<div class="stars-container">

						<?php for ($i=0; $i < 5; $i++) { ?>
						<div class="stary indexno-<?=$i?>" data-index="<?=$i?>" onclick="selectRating(event)">
							<i class="fa fa-star"></i>

						</div>
						<?php } ?>
					</div>
				</div>
				<div class="modal-footer">
					<button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
					<button type="button" class="btn btn-primary" data-dismiss="modal" onclick="rate()">Submit
						Rating</button>
				</div>
			</div>
		</div>
	</div>
	<div class="modal fade" id="expanded-images" tabindex="-1" role="dialog" aria-labelledby="expanded-imagesLabel"
		aria-hidden="true">
		<div class="modal-dialog" role="document">
			<div class="modal-content">
				<div class="modal-header">
					<h5 class="modal-title" id="expanded-imagesLabel">
						Image
					</h5>
					<button type="button" class="close" data-dismiss="modal" aria-label="Close">
						<span aria-hidden="true">&times;</span>
					</button>
				</div>
				<div class="modal-body">
					<div class="full-image"></div>
				</div>
				<div class="modal-footer">
					<button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>

				</div>
			</div>
		</div>
	</div>
    
</body>

<script src="view.js"></script>

<?php include 'footer.php'; ?>

</html>