function calculateFinalPrice() {
  var price = 0;
  $(".service-checkbox:checked").each((i, v) => {
    price += parseInt($(v).data("price"));
  });
  $(`.final-price`).html(`${price + parseInt($('[name="main_price"]').val())} BD`);
  $(`[name="finalPrice"]`).val(`${price + parseInt($('[name="main_price"]').val())} BD`);
}
