function searchKashtat(event, fromotherpage) {
  if (fromotherpage) {
    event.stopPropagation();
    event.preventDefault();
    $(".searchForm").submit();
  }
}
function msg(text) {
  $(".toast").toast("show");
  $(".toast-body").html(text);
}
