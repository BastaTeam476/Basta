function addComment() {
  $.ajax({
    type: "POST",
    url: "add-comment.php",
    data: JSON.stringify({ comment: $("#comment").val(), kashta_id: $(`[name="kashta_id"]`).val() }),
    headers: {
      "Content-Type": "application/json; charset=utf-8",
      Accept: "*/*",
    },
    dataType: "json",
    success: function (response) {
      msg(response?.message);

      if (response.comments.length) {
        $(".comment-section").html(``);

        response.comments.forEach((element) => {
          $(".comment-section").append(`
		<div class="commentblock">
			<p>${element.description}</p>
			<div class="time-block">
				<div class="user-p">
					<div>
						<div class="mini-profilepic" style="background-image:url('ProfileImages/${element.img}')"></div>
					</div>
					<div>${element.name}</div>
				</div>
				<div>
					<b>${element.created_at}</b>
				</div>
			</div>
		</div>`);
        });
      }
    },
    error: function (response) {
      msg(response?.responseJSON?.message);
    },
    complete: function (data) {
      $("html, body").animate(
        {
          scrollTop: 0,
        },
        500
      );
    },
  });
}
function selectRating(event) {
  var i = $(event.target).closest(".stary").data("index");
  $(".stary").removeClass("hovereffect");
  for (let index = 0; index <= i; index++) {
    $(".indexno-" + index).addClass("hovereffect");
  }
  $("#selectStars").val(parseInt(i) + 1);
}
function rate() {
  $(".stary").removeClass("hovereffect");
  var selectedRating = $(`#selectStars`).val();
  $(`#selectStars`).val("");

  $.ajax({
    type: "POST",
    url: "add-rating.php",
    data: JSON.stringify({ selectedRating, kashta_id: $(`[name="kashta_id"]`).val() }),
    headers: {
      "Content-Type": "application/json; charset=utf-8",
      Accept: "*/*",
    },
    dataType: "json",
    success: function (response) {
      msg(response?.message);

      $(`.stars-container`).html(``);
      if (response?.ratings.length) {
        var starsum = 0;
        response?.ratings.forEach((rating) => {
          starsum += parseInt(rating.stars);
        });

        var average = (starsum / response?.ratings.length).toPrecision(1);
        var floored = Math.floor(average);

        for (let index = 0; index < 5; index++) {
          $(`.stars-container`).append(`
			<div class="starx ${floored >= index + 1 ? "hovereffect" : ""} ">
				<i class="fa fa-star" aria-hidden="true"></i>
			</div>`);
        }
        $(`.stars-container`).append(`<div>(${average})</div>`);
      }
    },
    error: function (response) {
      msg(response?.responseJSON?.message);
    },
    complete: function (data) {
      $("html, body").animate(
        {
          scrollTop: 0,
        },
        500
      );
    },
  });
}
function initImageModal(event) {
  var imageurl = $(event.target).closest(".kashta-image").data("imageurl");
  $(".full-image").css("background-image", `url('${imageurl}')`);
}
