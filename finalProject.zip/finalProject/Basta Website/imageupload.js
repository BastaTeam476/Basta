function file_change(e) {
  var src = URL.createObjectURL(e.target.files[0]);

  $(`.image-upload-container`).html(`<div class="uimg" style="background-image: url('${src}')"></div>`);
}
