<?php
include_once('connection.php');
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}
$userQuery='select users.*, customer.first_name ,customer.last_name from users left join customer on customer.id = users.customer_id where users.id = :id';
$errors = [];
$msg = "";
if(isset($_POST['sb'])){

	$q = $db->prepare($userQuery);
	$q->bindParam(':id', $_SESSION['login_user']['id']);
	$q->execute();

	$q->setFetchMode(PDO::FETCH_ASSOC);
	$user = $q->fetch();

	if(!preg_match("/^[a-zA-Z.0-9]+$/i", $_POST['username'])){
		$errors[]="Username contains invalid characters";
	}
	if($user['customer_id']){
		if(!preg_match("/^[a-zA-Z ]+$/i", $_POST['firstname'])){
			$errors[]="First name may only contain letters and spaces.";
		}
		if(!preg_match("/^[a-zA-Z ]+$/i", $_POST['lastname'])){
			$errors[]="Lastname name may only contain letters and spaces.";
		}
		}
	if(!preg_match("/^[A-Za-z0-9.]{2,}@[A-Za-z0-9.]{2,}\.[A-Za-z0-9.]{2,}$/i", $_POST['email'])){
		$errors[]="Entered email is not well-formed.";
		
	}
	if(!preg_match("/^[0-9]{8}$/i", $_POST['phone'])){
		$errors[]="Phone number must contain exactly 8 numbers.";
	}

	if($_POST['password'] != $_POST['rpt_password']){
		$errors[]="Passwords doesnt match";
	}
	if(count($errors)){
		// echo"<br>";
		// foreach ($errors as $key => $value) {
		// 	echo "<p style='color:#d92f2f'>$value</p>";
		// 	// echo"<br>";
		// }
	}else{
		$db->beginTransaction();

		if($user['customer_id']){


			$stmt = $db->prepare("UPDATE `customer` SET `first_name` = :firstname, `last_name` = :lastname WHERE id=:id");

			$stmt->bindParam(':firstname',$_POST['firstname']);
			$stmt->bindParam(':lastname',$_POST['lastname']);
			$stmt->bindParam(':id',$user['customer_id']);
			
			$stmt->execute(); 
		}

		$filename = $user['profile_image'];
		if(file_exists($_FILES['profile_image']['tmp_name'])){
			$time = time();
			$filename = $time.basename( $_FILES['profile_image']['name']);
			move_uploaded_file($_FILES['profile_image']['tmp_name'], 'ProfileImages/' . $filename);
		}
		$stmt = $db->prepare("
		UPDATE `users`
		SET
		`username` = :username,
		`password` = :password, 
		`phone` = :phone, 
		`email` = :email, 
		`profile_image` = :profile_image 
		WHERE id = :id;");

		$stmt->bindParam(':username',$_POST['username']);
		$stmt->bindParam(':password',$_POST['password']);
		$stmt->bindParam(':email',$_POST['email']);
		$stmt->bindParam(':phone',$_POST['phone']);
		$stmt->bindParam(':profile_image',$filename);
		$stmt->bindParam(':id',$_SESSION['login_user']['id']);

		$stmt->execute();					
		$db->commit();

		$msg= "User Updated.";

		$q = $db->prepare($userQuery);
		$q->bindParam(':id', $_SESSION['login_user']['id']);
		$q->execute();
	
		$q->setFetchMode(PDO::FETCH_ASSOC);
		$user = $q->fetch();

		$_SESSION['login_user'] = $user;
	}							
}
?>

<!DOCTYPE html>
<html lang="en">
<?php include 'header.php'; ?>

<head>

	<title> sign up</title>
</head>


<body>
	<main>
		<?php
			


			$q = $db->prepare($userQuery);
			$q->bindParam(':id', $_SESSION['login_user']['id']);
			$q->execute();

			$q->setFetchMode(PDO::FETCH_ASSOC);
			$seuser = $q->fetch();
			
			
		?>
		<div class="container-signup">
			<h1 style="color:#776559"> Change Account Details</h1><br/>

			<script src="imageupload.js"></script>

			<form method="post" action="<?php echo $_SERVER['PHP_SELF']; ?>" id="signup-form"
				enctype="multipart/form-data"><br/>


				<div class="form-row">
					<div class="col-md-12">
						<div class="image-upload-container">
							<?php if($seuser['profile_image']){ ?>
							<div class="uimg"
								style="background-image: url('<?php echo 'ProfileImages/'.$seuser["profile_image"]; ?>">
							</div><br/>
							
						</div>
					</div>
				</div>

				<div class="form-row">
					<div class="form-group col-md-12">
						<label for="profile_image">Upload Profile Image</label>
						<input style="height: calc(1.5em + 0.75rem + 10px);" onchange="file_change(event)" type="file"
							class="form-control" name="profile_image" id="profile_image">
					</div>
				</div>
				



				<div class="form-row">
					<div class="form-group col-md-12">
						<label for="username">Username</label>
						<input type="text" class="form-control" name="username" id="username"
							value="<?php echo $seuser["username"] ?>">
					</div>
					<div class="form-group col-md-6">
						<label for="password">Password</label>
						<input type="password" class="form-control" name="password" id="password"
							value="<?php echo $seuser["password"] ?>">
					</div>
					<div class="form-group col-md-6">
						<label for="rpassword">Repeat Password</label>
						<input type="password" class="form-control" name="rpt_password" id="rpassword"
							value="<?php echo $seuser["password"] ?>">
					</div>
				</div>

				<?php if($seuser['customer_id']){ ?>
				<div class="form-row">
					<div class="form-group col-md-6">
						<label for="first">First name</label>
						<input type="text" name="firstname" class="form-control" id="first"
							value="<?php echo $seuser["first_name"] ?>">
					</div>
					<div class="form-group col-md-6">
						<label for="last">Last name</label>
						<input type="text" name="lastname" class="form-control" id="last"
							value="<?php echo $seuser["last_name"] ?>">
					</div>
				</div>
				<?php } ?>



				<div class="form-row">
					<div class="form-group col-md-6">
						<label for="email">Email</label>
						<input type="text" class="form-control" name="email" id="email"
							value="<?php echo $seuser["email"] ?>">
					</div>
					<div class="form-group col-md-6">
						<label for="phone">Phone number</label>
						<input type="number" class="form-control" id="phone" name="phone"
							value="<?php echo $seuser["phone"] ?>">
					</div>
				</div>

				<?php } ?>

				<!--
				<div class="form-row">
					<div class="form-group col-md-12">
						<label for="profile_image">Upload Profile Image</label>
						<input style="height: calc(1.5em + 0.75rem + 10px);" onchange="file_change(event)" type="file"
							class="form-control" name="profile_image" id="profile_image">
					</div>
				</div>
				<div class="form-row">
					<div class="col-md-12">
						<div class="image-upload-container">
							<?php if($seuser['profile_image']){ ?>
							<div class="uimg"
								style="background-image: url('<?php echo 'ProfileImages/'.$seuser["profile_image"]; ?>">
							</div>
							<?php } ?>
						</div>
					</div>
				</div>
							-->

				<input type="hidden" name="sb">
				<?php
				echo "";

				if(count($errors)){
					echo"<br>";
					foreach ($errors as $key => $value) {
						echo "<p style='color:#d92f2f'>$value</p>";
						// echo"<br>";
					}
				}

				echo $msg."<br/>";
				?>
				<button class="btn btn-primary" onclick="signup(event)" style="display: inline-block; margin-bottom: 20px;">Update Info</button>



			</form>
		</div>
	</main>
	<script src="signup.js"></script>
</body>
<?php include 'footer.php'; ?>

</html>