<!DOCTYPE html>
<html lang="en">
<?php include 'header.php'; ?>
<?php $success = false; ?>

<head>

	<title> sign up</title>
</head>


<body>
	<main>

		<div class="container-signup">
			<h1 style="color:#776559"> Create Account</h1>

			<script src="imageupload.js"></script>

			<form method="post" action="<?php echo $_SERVER['PHP_SELF']; ?>" id="signup-form"
				class="<?=isset($_POST['sb'])?"was-validated":""?>" enctype="multipart/form-data">

				<div class="form-row">
					<div class="form-group col-md-12">
						<label for="username">Username</label>
						<input type="text" class="form-control" name="username" id="username"
							value="<?=(!$success && isset($_POST['sb']))?$_POST['username']:""?>">
						<!-- <div class="valid-feedback">Valid.</div> -->
						<div class="invalid-feedback">Username contains invalid characters</div>
					</div>
					<div class="form-group col-md-6">
						<label for="password">Password</label>
						<input type="password" class="form-control" name="password" id="password"
							value="<?=(!$success && isset($_POST['sb']))?$_POST['password']:""?>">
						<div class="invalid-feedback">Passwords doesn't match</div>
					</div>
					<div class="form-group col-md-6">
						<label for="rpassword">Repeat Password</label>
						<input type="password" class="form-control" name="rpt_password" id="rpassword"
							value="<?=(!$success && isset($_POST['sb']))?$_POST['rpt_password']:""?>">
						<div class="invalid-feedback">Passwords doesn't match</div>

					</div>
				</div>

				<div class="form-row">
					<div class="form-group col-md-6">
						<label for="first">First name</label>
						<input type="text" name="firstname" class="form-control" id="first"
							value="<?=(!$success && isset($_POST['sb']))?$_POST['firstname']:""?>">
						<div class="invalid-feedback">First name may only contain letters and spaces.</div>

					</div>
					<div class="form-group col-md-6">
						<label for="last">Last name</label>
						<input type="text" name="lastname" class="form-control" id="last"
							value="<?=(!$success && isset($_POST['sb']))?$_POST['lastname']:""?>">
						<div class="invalid-feedback">Last name may only contain letters and spaces.</div>

					</div>
				</div>

				<div class="form-row">
					<div class="form-group col-md-6">
						<label for="email">Email</label>
						<input type="text" class="form-control" name="email" id="email"
							value="<?=(!$success && isset($_POST['sb']))?$_POST['email']:""?>">
						<div class="invalid-feedback">Entered email is not well-formed.</div>
					</div>
					<div class="form-group col-md-6">
						<label for="phone">Phone number</label>
						<input type="number" class="form-control" id="phone" name="phone"
							value="<?=(!$success && isset($_POST['sb']))?$_POST['phone']:""?>">
						<div class="invalid-feedback">Phone number must contain exactly 8 numbers.</div>
					</div>
				</div>
				<div class="form-row">
					<div class="form-group col-md-12">
						<label for="profile_image">Upload Profile Image</label>
						<input style="height: calc(1.5em + 0.75rem + 10px);" onchange="file_change(event)" type="file"
							class="form-control" name="profile_image" id="profile_image">
						<div class="invalid-feedback">You have to upload a profile picture.</div>


					</div>
				</div>
				<div class="form-row">
					<div class="col-md-12">
						<div class="image-upload-container"></div>
					</div>
				</div>
				<input type="hidden" name="sb">
				<button class="btn btn-primary" onclick="signup(event)">Sign up</button>
				<?php
				echo "<br/><br/>";
				
				$exist_email = false;
					if(isset($_POST['sb'])){
						$errors = [];
						if(!preg_match("/^[a-zA-Z.0-9]+$/i", $_POST['username'])){
							$errors[]="Username contains invalid characters";
						}
						if(!preg_match("/^[a-zA-Z ]+$/i", $_POST['firstname'])){
							$errors[]="First name may only contain letters and spaces.";
						}
						if(!preg_match("/^[a-zA-Z ]+$/i", $_POST['lastname'])){
							$errors[]="Lastname name may only contain letters and spaces.";
						}
						if(!preg_match("/^[A-Za-z0-9.]{2,}@[A-Za-z0-9.]{2,}\.[A-Za-z0-9.]{2,}$/i", $_POST['email'])){
							$errors[]="Entered email is not well-formed.";
							
						}
						if(!preg_match("/^[0-9]{8}$/i", $_POST['phone'])){
							$errors[]="Phone number must contain exactly 8 numbers.";
						}
						$q = $db->prepare('select * from users where username = :username or email = :email');
						$q->bindParam(':username', $_POST['username']);
						$q->bindParam(':email', $_POST['email']);
						$q->execute();
				
						$q->setFetchMode(PDO::FETCH_ASSOC);
						$users = $q->fetchAll();
						
						if(count($users)){
							$errors[]= "Username/Email was already found. Please use another username.";
							$exist_email = true;
							?>
				<script>
				$('#username').closest('.form-group').children('.invalid-feedback').text(
					"Username/Email was already found. Please use another username.")
				$('#email').closest('.form-group').children('.invalid-feedback').text(
					"Username/Email was already found. Please use another username.");

				document.querySelector('#email').setCustomValidity("INVALID");
				document.querySelector('#username').setCustomValidity("INVALID");
				</script>
				<?php
						}

						if(!preg_match("/^.{5,}$/i", $_POST['password'])){
							$errors[]="Passwords should containt atleast 5 characters or more.";
						}

						if($_POST['password'] != $_POST['rpt_password']){
							$errors[]="Passwords doesnt match";
						}
						if(count($errors)){
							echo"<br>";
							echo "<div class='errorcontainer'>";
							foreach ($errors as $key => $value) {
								echo "<p style='color:#d92f2f'>$value</p>";
								// echo"<br>";
							}
							echo "</div>";
						}else{
							$db->beginTransaction();

							$stmt = $db->prepare("INSERT INTO `customer` (`first_name`, `last_name`) VALUES (:firstname, :lastname);");
	
							$stmt->bindParam(':firstname',$_POST['firstname']);
							$stmt->bindParam(':lastname',$_POST['lastname']);
							
							$stmt->execute();
							
							$customer_id = $db->lastInsertId();
							$filename = "";

							if(file_exists($_FILES['profile_image']['tmp_name'])){
								$time = time();
								$filename = $time.basename( $_FILES['profile_image']['name']);
								move_uploaded_file($_FILES['profile_image']['tmp_name'], 'ProfileImages/' . $filename);
							}
							$stmt = $db->prepare("INSERT INTO `users` 
							(`username`, `password`, `phone`, `email`, `customer_id`, `profile_image`) VALUES 
							(:username, :password, :phone, :email, :customer_id, :profile_image);");
							$hash = hash('md5', $_POST['password']);
							$stmt->bindParam(':username',$_POST['username']);
							$stmt->bindParam(':password',$hash);
							$stmt->bindParam(':email',$_POST['email']);
							$stmt->bindParam(':phone',$_POST['phone']);
							$stmt->bindParam(':profile_image',$filename);
							$stmt->bindParam(':customer_id',$customer_id);
							
							$stmt->execute();					
							$db->commit();

							

							echo "User registered!";
							$success = true;
						}							
					}
				?>

				<h6>Already have account? <a href="login.php">
						Log in
					</a></h6>


			</form>
		</div>
	</main>
	<script src="signup.js"></script>

</body>
<?php include 'footer.php'; ?>

</html>