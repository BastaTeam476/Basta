<?php include 'login.guard.php' ?>


<?php include 'header.php';?>
<?php
if(isset($_GET['booking_id'])){


	
$q = $db->prepare('select * from booking where id = :id');
$q->bindParam(':id', $_GET['booking_id']);
$q->execute();

$q->setFetchMode(PDO::FETCH_ASSOC);
$booking = $q->fetch();

$q = $db->prepare('select * from kashta where id = :id');
$q->bindParam(':id', $booking['kashta_id']);
$q->execute();

$q->setFetchMode(PDO::FETCH_ASSOC);
$kashta = $q->fetch();

$q = $db->prepare('select * from kashta_images where kashta_id = :id');
$q->bindParam(':id', $kashta['id']);
$q->execute();

$q->setFetchMode(PDO::FETCH_ASSOC);
$kashta_images = $q->fetchAll();
}
 ?>

<html>

<link rel="stylesheet" href="S_1.css">
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/css/bootstrap.min.css"
	integrity="sha384-xOolHFLEh07PJGoPkLv1IbcEPTNtaed2xpHsD9ESMhqIYd0nLMwNLD69Npy4HI+N" crossorigin="anonymous">

<body>
	<div class="card mb-3 " style="background-color:rgba(196, 164, 132, 0.4); width: 70%;">

		<div id="<?="carousel".$kashta['id']?>" class="carousel slide" data-ride="carousel" data-interval="<?=2000?>">
			<ol class="carousel-indicators">
				<?php foreach ($kashta_images as $img_index => $image) { ?>
				<li data-target="#<?="carousel".$kashta['id']?>" data-slide-to="<?=$img_index?>"
					<?=$img_index==0?"class='active'":""?>></li>
				<?php } ?>
			</ol>
			<div class="carousel-inner">
				<div class="capacityrange">
					<i class="fa fa-user"></i> <?=$kashta['min_capacity']?> -
					<?=$kashta['max_capacity']?>
				</div>
				<?php foreach ($kashta_images as $img_index => $image) { ?>
				<div class="carousel-item <?=$img_index==0?"active":""?>">

					<div class="kashta-image w-100"
						style="background-image:url('Kashta Pics/<?=$kashta['id']."/".$image['filename']?>')">
					</div>
				</div>
				<?php } ?>
			</div>
			<a class="carousel-control-prev" href="#<?="carousel".$kashta['id']?>" role="button" data-slide="prev">
				<span class="carousel-control-prev-icon" aria-hidden="true"></span>
				<span class="sr-only">Previous</span>
			</a>
			<a class="carousel-control-next" href="#<?="carousel".$kashta['id']?>" role="button" data-slide="next">
				<span class="carousel-control-next-icon" aria-hidden="true"></span>
				<span class="sr-only">Next</span>
			</a>
		</div>
		<div style="background-color:rgb(196, 164, 132)">
			<h5 class="card-body"><?=$kashta['name']?></h5>

		</div>
		<form id="receiptform" target="_blank" action="receipt.php?booking_id=<?=$_GET['booking_id']?>" method="POST"
			style="margin-bottom: 55px;margin-right:50px;">
			<input type="hidden" value="<?=$kashta['price']?>" name="main_price" />
			<input type="hidden" value="<?=$kashta['id']?>" name="kashta_id" />
			<ul><br />

				<?php
					$success = false;
				?>
				<h3 class="myh3">Min price : <?=$kashta['price']?> BD</h3></br>
				<b class="h4" id="myh">Extra Services :</b><br><br>
				<?php
				$q = $db->prepare('select * from kashta_services');
				$q->execute();
		
				$q->setFetchMode(PDO::FETCH_ASSOC);
				$services = $q->fetchAll();
?>
				<div class="row">

					<?php
                    if(!isset($_POST['service_ids'])){
                        echo "<p>\t\t\t\tNo extra services</p>";
                    }
                    else if(isset($_POST['service_ids'])){
				foreach ($services as $service_index => $service) {
					if(in_array($service['id'],$_POST['service_ids'])){
					?>

					<div class="col-md-6">
						<div class="d-flex align-items-baseline myh3" style="gap:15px">
							<input type="hidden" name="service_description[]" value="<?=$service['description']?>">
							<input type="hidden" name="service_price[]" value="<?=$service['added_price']?>">
							<input type="hidden" name="service_icon[]" value="<?=$service['icon']?>">
							<input disabled
								<?=isset($_POST['subreserve']) && (!$success) && in_array($service['id'],isset($_POST['service_ids'])?$_POST['service_ids']:[])?"checked":""?>
								onchange="calculateFinalPrice()" type="checkbox" name="service_ids[]"
								id="service<?=$service_index?>" value='<?=$service['id']?>' class="service-checkbox"
								data-price="<?=$service['added_price']?>"><label for='service<?=$service_index?>'>
								<img width="25" src="icons/<?= $service['icon'] ?>" />

								<?=$service['description']?> -
								<?=$service['added_price']?> BD</label>
						</div>
					</div>



					<br />
					<?php
					}
					}} ?>
				</div>
				<div class="row">
					<div class="col-md-6">
						<h3 class="myh3">Choose a Date:</h3>
						<input type="hidden" name="KashtaName" value="<?=$kashta['name']?>">
						<input type="hidden" name="pickedDate" value="<?=$_POST['date']?>">

						<input disabled type="date" id="date" name="date"
							value="<?=isset($_POST['subreserve']) && (!$success)?$_POST['date']:""?>"> <br /><br />
					</div>
					<div class="col-md-6">
						<h3 class="myh3">Choose a timing:</h3>
						<input type="hidden" name="pickedTiming" value="<?=$_POST['timing']?>">

						<input disabled type="radio" name="timing" id="timin1" value="5am - 1pm"
							<?=isset($_POST['subreserve']) && (!$success)?(isset($_POST['timing'])?$_POST['timing']:"") =="5am - 1pm"?"checked":"":""?>><label
							for="timin1">5am -
							1pm</label>
						<br />
						<input disabled type="radio" name="timing" id="timin2" value="5pm - 1am"
							<?=isset($_POST['subreserve']) && (!$success)?(isset($_POST['timing'])?$_POST['timing']:"") =="5pm - 1am"?"checked":"":""?>><label
							for="timin2">5pm - 1am</label>
						<br />
					</div>
				</div>

				<div class="row">
					<div class="col-md-6">
						<h3 class="myh3">Place :</h3>
						<input disabled type="text" cols=10 id="place" name="place" placeholder="Where is your place"
							value="<?=isset($_POST['subreserve']) && (!$success)?$_POST['place']:""?>" />
						<input type="hidden" name="pickedPlace"
							value="<?=isset($_POST['subreserve']) && (!$success)?$_POST['place']:""?>">


					</div>
					<div class="col-md-12">
						<br><h3 class="myh3">Location:</h3><br>
						<input type="hidden" name="pickedLocation" value="<?=$_POST['location']?>">

						<!-- <input disabled type="text" id="location" name="location"
							value="<?=isset($_POST['subreserve']) && (!$success)?$_POST['location']:""?>" /> -->

						<iframe src="<?=isset($_POST['subreserve']) && (!$success)?$_POST['location']:""?>" width="100%"
							height="450" style="border:0;" allowfullscreen="" loading="lazy"
							referrerpolicy="no-referrer-when-downgrade"></iframe>
						<br /><br />
					</div>

				</div>


				<h3 class="myh3">Final Price : </h3>
				<input type="hidden" name="finalPrice">

				<b class="final-price">
					<?=$kashta['price']?> BD
				</b> <br /><br />

				<input type="submit" class="btn btn-primary" name="subreserve" value="Print Receipt">
				<a href="bookings.php" class="btn btn-primary">
					Back
				</a>
			</ul>
		</form>
	</div>

	</div>
	</div>

</body>
<script src="reservation.js"></script>
<?php
if(isset($_POST['subreserve']) && (!$success)){
?>
<script>
calculateFinalPrice();
</script>
<?php
}
?>
<?php include 'footer.php'; ?>
<?php if(isset($_GET['receipt'])){?>
<script>
setTimeout(() => {
	$('#receiptform').submit();
}, 500);
</script>
<?php } ?>

</html>