<!DOCTYPE html>
<html lang="en">
<?php include 'header.php'; ?>

<body>
	<main>
		<div class="container-signup">
			<h1 style="color:#776559"> Add Kastha</h1>

			<script src="imageupload.js"></script>

			<form method="post" action="<?php echo $_SERVER['PHP_SELF']; ?>" id="signup-form"
				enctype="multipart/form-data">

				<div class="form-row">
					<div class="form-group col-md-12">
						<label for="name">Name</label>
						<input type="text" class="form-control" name="name" id="name"
							value="<?php echo isset($_POST['sb'])?$_POST['name']:"" ?>">
					</div>
					<div class="form-group col-md-6">
						<label for="description">Description</label>
						<!-- <input type="text" class="form-control" name="description" id="description"
							value="<?php echo isset($_POST['sb'])?$_POST['description']:"" ?>"> -->

						<textarea class="form-control" name="description" id="description"
							rows="1"><?php echo isset($_POST['sb'])?$_POST['description']:"" ?></textarea>
					</div>
					<div class="form-group col-md-6">
						<label for="price">Price</label>
						<input type="text" class="form-control" name="price" id="price"
							value="<?php echo isset($_POST['sb'])?$_POST['price']:"" ?>">
					</div>

				</div>
				<div class="form-row">
					<div class="form-group col-md-6">
						<label for="min_capacity">Minimum Capacity</label>
						<input type="text" class="form-control" name="min_capacity" id="min_capacity"
							value="<?php echo isset($_POST['sb'])?$_POST['min_capacity']:"" ?>">
					</div>
					<div class="form-group col-md-6">
						<label for="max_capacity">Maximum Capacity</label>
						<input type="text" class="form-control" name="max_capacity" id="max_capacity"
							value="<?php echo isset($_POST['sb'])?$_POST['max_capacity']:"" ?>">
					</div>
				</div>

				<div class="form-row">
					<div class="form-group col-md-12">
						<label for="kashta_images">Upload Kashta Images</label>
						<input style="height: calc(1.5em + 0.75rem + 10px);" onchange="file_change(event)" type="file"
							multiple class="form-control" name="kashta_images[]" id="kashta_images">
					</div>
				</div>
				<div class="form-row">
					<div class="col-md-4">
						<div class="image-upload-container"></div>
					</div>
				</div>
				<input type="hidden" name="sb">
				<button class="btn btn-primary">
					Submit
				</button>
				<?php
				echo "<br/><br/>";
					if(isset($_POST['sb'])){
						
						$errors = [];

						if(!preg_match("/^[a-zA-Z ]+$/i", $_POST['name'])){
							$errors[]="Kashta name may only contain letters and spaces.";
						}
						if(!preg_match("/^[a-zA-Z ]+$/i", $_POST['description'])){
							$errors[]="Lastname name may only contain letters and spaces.";
						}
						if(!preg_match("/^[0-9]+$/i", $_POST['price'])){
							$errors[]="Price may only contain one or more number.";
						}
						if(!preg_match("/^[0-9]+$/i", $_POST['min_capacity'])){
							$errors[]="Minimum Capacity may only contain one or more number.";
						}
						if(!preg_match("/^[0-9]+$/i", $_POST['max_capacity'])){
							$errors[]="Maximum Capacity may only contain one or more number.";
						}
						if($_POST['max_capacity'] < $_POST['min_capacity']){
							$errors[]="Maximum Capacity cannot be lesser than minimum capacity.";
						}
						$q = $db->prepare('select * from kashta where name = :name');
						$q->bindParam(':name', $_POST['name']);
						$q->execute();
				
						$q->setFetchMode(PDO::FETCH_ASSOC);
						$users = $q->fetchAll();
						
						if(count($users)){
							$errors[]= "Kashta name was already found. Please use another name.";
						}

						if(count($errors)){
							echo"<br>";
							foreach ($errors as $key => $value) {
								echo "<p style='color:#d92f2f'>$value</p>";
								// echo"<br>";
							}
						}else{
							$db->beginTransaction();

							$stmt = $db->prepare("INSERT INTO `kashta` 
							(`name`, `description`, `price`, `admin_id`, `min_capacity`,`max_capacity`) 
							VALUES 
							(:name, :description, :price, :admin_id, :min_capacity, :max_capacity);");
	
							$stmt->bindParam(':name',$_POST['name']);
							$stmt->bindParam(':description',$_POST['description']);
							$stmt->bindParam(':price',$_POST['price']);
							$stmt->bindParam(':min_capacity',$_POST['min_capacity']);
							$stmt->bindParam(':max_capacity',$_POST['max_capacity']);
							$stmt->bindParam(':admin_id',$_SESSION['login_user']['id']);
							
							$stmt->execute();
							$kashta_id = $db->lastInsertId();


							
							$kashta_imgs_directory = 'Kashta Pics/'.$kashta_id;

							if (!file_exists($kashta_imgs_directory)) {
								mkdir($kashta_imgs_directory, 0777, true);
							}

							if(count($_FILES['kashta_images']['tmp_name'])){
								// $db->beginTransaction();
								foreach($_FILES["kashta_images"]["tmp_name"] as $key=>$tmp_name) {
									$time = time();
									$filename = $time.basename( $_FILES['kashta_images']['name'][$key]);
									move_uploaded_file($_FILES['kashta_images']['tmp_name'][$key], $kashta_imgs_directory.'/' . $filename);

									$stmt = $db->prepare("INSERT INTO `kashta_images` (`filename`, `kashta_id`) VALUES (:filename, :kashta_id);");
									$stmt->bindParam(':filename',$filename);
									$stmt->bindParam(':kashta_id',$kashta_id);
									$stmt->execute();
								}
								// $db->commit();
							}
							$db->commit();

							echo "Kashta added.";
						}							
					}
				?>
			</form>
		</div>
	</main>
	<script src="add-update-kashta.js"></script>
</body>
<?php include 'footer.php'; ?>

</html>