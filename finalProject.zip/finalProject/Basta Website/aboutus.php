<?php include 'header.php';?>
<!DOCTYPE html>
<html lang="en">

<head>
	<meta charset="UTF-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<title>Document</title>
	<link rel="stylesheet" href="S_1.css">
</head>

<body>
	<main>
		<div class="hero">
			<div class="herobox1">
				<img src="logo1r.png" width=300 height=auto>
			</div>
			<div class="herobox2">
				<h3>About us:-</h3><br/>
				<p>Our site has been published in 2022 . It was done by a team of students who are
					Zainab Ebrahim , Wafaa Ebrahim , Zahraa Alsayed Jaffer, Fatima Al-zaki and Zainab Alsayed.
					The site offers a variety of bastas to the costumers where they can reserve them with their suitable
					date, time
					and location.
				</p>
				</p>
			</div>
		</div>
	</main>

</body>
<?php include 'footer.php';?>

</html>