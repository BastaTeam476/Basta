function signup(event) {
  event.stopPropagation();
  event.preventDefault();

  var erros = [];
  var allElements = [
    `input[name="username"]`,
    `input[name="lastname"]`,
    `input[name="firstname"]`,
    `input[name="email"]`,
    `input[name="phone"]`,
    `input[name="password"]`,
    `input[name="rpt_password"]`,
    `#profile_image`,
    `#rpassword`,
  ];

  allElements.forEach((q) => {
    document.querySelector(q).setCustomValidity("");
  });
  if (!/^[a-zA-Z.0-9]+$/g.test($(`input[name="username"]`).val())) {
    erros.push(`input[name="username"]`);
    $("#username").closest(".form-group").children(".invalid-feedback").text("Username contains invalid characters");
  }
  if (!/^[a-zA-Z ]+$/g.test($(`input[name="lastname"]`).val())) {
    erros.push(`input[name="lastname"]`);
  }
  if (!/^[a-zA-Z ]+$/g.test($(`input[name="firstname"]`).val())) {
    erros.push(`input[name="firstname"]`);
  }
  if (!/^[A-Za-z0-9.]{2,}@[A-Za-z0-9.]{2,}\.[A-Za-z0-9.]{2,}$/g.test($(`input[name="email"]`).val())) {
    erros.push(`input[name="email"]`);
    $("#username").closest(".form-group").children(".invalid-feedback").text("Entered email is not well-formed.");
  }
  if (!/^[0-9]{8}$/g.test($(`input[name="phone"]`).val())) {
    erros.push(`input[name="phone"]`);
  }
  var invalidpasswordtxt = "";
  var invalidrptpasswordtxt = "";
  if (!/^.{5,}$/g.test($(`input[name="password"]`).val())) {
    invalidpasswordtxt += "Password should atleast contain 5 or more characters.<br/>";
    erros.push(`input[name="password"]`);
  }
  if (!/^.{5,}$/g.test($(`#rpassword`).val())) {
    invalidrptpasswordtxt += "Password should atleast contain 5 or more characters.<br/>";
    erros.push(`input[name="rpt_password"]`);
  }

  if ($(`input[name="rpt_password"]`).val() !== $(`input[name="password"]`).val()) {
    invalidpasswordtxt += "Passwords doesnt match.<br/>";
    invalidrptpasswordtxt += "Passwords doesnt match.<br/>";
    erros.push(`input[name="password"]`);
    erros.push(`input[name="rpt_password"]`);
  }

  if (invalidpasswordtxt !== "") {
    $('input[name="password"]').closest(".form-group").children(".invalid-feedback").html(invalidpasswordtxt);
  }
  if (invalidrptpasswordtxt !== "") {
    $('input[name="rpt_password"]').closest(".form-group").children(".invalid-feedback").html(invalidpasswordtxt);
  }

  if (document.getElementById("profile_image").files.length === 0) {
    erros.push(`#profile_image`);
  }

  if (erros.length) {
    // alert(erros.join("\n"));
    erros.forEach((q) => {
      document.querySelector(q).setCustomValidity("INVALID");
    });
    $("#signup-form").addClass("was-validated");

    $(".errorcontainer").hide();
  } else {
    $("#signup-form").submit();
  }
}
