<?php include 'header.php';?>
<!DOCTYPE html>
<html lang="en">

<head>
	<meta charset="UTF-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<title>Document</title>
	<link rel="stylesheet" href="S_1.css">
</head>

<body>
	<main>
		<div class="hero">
			<div class="herobox1">
				<img src="logo1r.png" width=300 height=auto>
			</div>
			<div class="herobox2">
				<h3>Join us:-</h3><br/>
				<p>If you wold like to be part of us please note that we are coming This website is provided by eXtra, a subsidiary of United Electronics Company in Bahrain. The website is operated by eXtra (referred to as "we/our/us"). As a user (referred to as "you/your/Customer") of the website, you must read and acknowledge below the following terms and conditions (the “Terms and Conditions”).By purchasing via the website, you agree to be bound by the Terms and Conditions.

Please read carefully before using the online service. We reserve the right to edit these Terms and Conditions at any time. Using the website after editing any of the Terms and Conditions is considered approval to be bound by these modified Terms and Conditions.
				</p>
				</p>
			</div>
		</div>
	</main>

</body>
<?php include 'footer.php';?>

</html>