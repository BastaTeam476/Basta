<?php include 'login.guard.php' ?>
<?php include 'header.php';?>

<?php
if(isset($_GET['kashta_id'])){
$q = $db->prepare('select * from kashta where id = :id');
$q->bindParam(':id', $_GET['kashta_id']);
$q->execute();

$q->setFetchMode(PDO::FETCH_ASSOC);
$kashta = $q->fetch();

$q = $db->prepare('select * from kashta_images where kashta_id = :id');
$q->bindParam(':id', $kashta['id']);
$q->execute();

$q->setFetchMode(PDO::FETCH_ASSOC);
$kashta_images = $q->fetchAll();
}
 ?>
<?php
$success = false;
$errors = [];
if(isset($_POST['subreserve'])){
	// echo "<pre>";
	// print_r($_POST);
	// echo "</pre>";

	if(!preg_match("/^https:\/\/www\.google\.com\/maps\/embed\?[A-Za-z=!0-9.%]+$/i", $_POST['location'])){
		$errors[]="Location url is not valid.";
	}
	
	if(!preg_match("/^[0-9]+((pm)|(am)) - [0-9]+((pm)|(am))$/i", (isset($_POST['timing'])?$_POST['timing']:""))){
		$errors[]="Please pick a proper timing";
	}

	if(!preg_match("/^[0-9]{4}-[0-9]{2}-[0-9]{2}$/i", (isset($_POST['date'])?$_POST['date']:""))){
		$errors[]="Please pick a proper date";
	}

	if(!preg_match("/^[a-zA-Z ]+$/i", (isset($_POST['place'])?$_POST['place']:""))){
		$errors[]="Place can only contiain letters and spaces.";
	}

	// $q = $db->prepare('select * from booking where user_id = :user_id and kashta_id = :kashta_id');
	// $q->bindParam(':user_id', $_SESSION['login_user']['id']);
	// $q->bindParam(':kashta_id', $kashta['id']);
	// $q->execute();

	// $q->setFetchMode(PDO::FETCH_ASSOC);
	// $bookings = $q->fetchAll();

	// if(count($bookings)){
	// 	$errors[]="User already booked this basta.";
	// }

	$q = $db->prepare('select * from booking where date = :date and timing = :timing');
	$q->bindParam(':timing',$_POST['timing']);
	$q->bindParam(':date',$_POST['date']);
	$q->execute();

	$q->setFetchMode(PDO::FETCH_ASSOC);
	$bookings = $q->fetchAll();

	if(count($bookings)){
		$errors[]="Kashta is already booked for the entered date and time. Please choose another timing and date.";
	}

	if(!count($errors)){
		$db->beginTransaction();

		$stmt = $db->prepare("
		INSERT INTO `booking` 
		(`date`, `timing`, `location`, `kashta_id`,`place`, `user_id`) VALUES 
		(:date, :timing, :location, :kashta_id,:place, :user_id);");

		$stmt->bindParam(':date',$_POST['date']);
		$stmt->bindParam(':timing',$_POST['timing']);
		$stmt->bindParam(':location',$_POST['location']);
		$stmt->bindParam(':place',$_POST['place']);
		$stmt->bindParam(':kashta_id',$kashta['id']);
		$stmt->bindParam(':user_id',$_SESSION['login_user']['id']);
		
		$stmt->execute();
		$booking_id = $db->lastInsertId();
		if(isset($_POST['service_ids'])){
			foreach ($_POST['service_ids'] as $sindex => $service_id) {
				$stmt = $db->prepare("
				INSERT INTO `booking_services` 
				(`booking_id`, `service_id`) VALUES 
				(:booking_id, :service_id);");
				$stmt->bindParam(':booking_id',$booking_id);
				$stmt->bindParam(':service_id',$service_id);

				$stmt->execute();

			}
		}
		$db->commit();
		$success = true;

		if($success){
			// echo "Booking is placed!";
			header("Location:bookings.php");
		}
	}
}


?>



<html>

<link rel="stylesheet" href="S_1.css">
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/css/bootstrap.min.css"
	integrity="sha384-xOolHFLEh07PJGoPkLv1IbcEPTNtaed2xpHsD9ESMhqIYd0nLMwNLD69Npy4HI+N" crossorigin="anonymous">

<body>
	<div class="card mb-3" style="background-color:rgba(196, 164, 132, 0.4); width: 70%;">

		<div id="<?="carousel".$kashta['id']?>" class="carousel slide" data-ride="carousel" data-interval="<?=2000?>">
			<ol class="carousel-indicators">
				<?php foreach ($kashta_images as $img_index => $image) { ?>
				<li data-target="#<?="carousel".$kashta['id']?>" data-slide-to="<?=$img_index?>"
					<?=$img_index==0?"class='active'":""?>></li>
				<?php } ?>
			</ol>
			<div class="carousel-inner">
				<div class="capacityrange">
					<i class="fa fa-user"></i> <?=$kashta['min_capacity']?> -
					<?=$kashta['max_capacity']?>
				</div>
				<?php foreach ($kashta_images as $img_index => $image) { ?>
				<div class="carousel-item <?=$img_index==0?"active":""?>">

					<div class="kashta-image w-100" data-toggle="modal" data-target="#expanded-images"
						onclick="initImageModal(event)"
						data-imageurl="Kashta Pics/<?=$kashta['id']."/".$image['filename']?>"
						style="cursor: pointer; background-image:url('Kashta Pics/<?=$kashta['id']."/".$image['filename']?>')">
					</div>
				</div>
				<?php } ?>
			</div>
			<a class="carousel-control-prev" href="#<?="carousel".$kashta['id']?>" role="button" data-slide="prev">
				<span class="carousel-control-prev-icon" aria-hidden="true"></span>
				<span class="sr-only">Previous</span>
			</a>
			<a class="carousel-control-next" href="#<?="carousel".$kashta['id']?>" role="button" data-slide="next">
				<span class="carousel-control-next-icon" aria-hidden="true"></span>
				<span class="sr-only">Next</span>
			</a>
		</div>
		<div style="background-color:rgb(196, 164, 132)">
			<h5 class="card-body"><?=$kashta['name']?></h5>

		</div>
		<form action="<?php echo $_SERVER['PHP_SELF']; ?>?kashta_id=<?=$kashta['id']?>" method="POST"
			style="margin-bottom: 55px;margin-right:50px;">
			<input type="hidden" value="<?=$kashta['price']?>" name="main_price" />
			<ul><br />
				<?php
					foreach ($errors as $key => $value) {
						echo "<p style='color:#d92f2f'>$value</p>";
					}
				?>
				<h3 class="myh3">Min price : <?=$kashta['price']?> BD</h3></br>
				<b class="h4" id="myh">Add Extra Services :</b><br><br>
				<?php
				$q = $db->prepare('select * from kashta_services');
				$q->execute();
		
				$q->setFetchMode(PDO::FETCH_ASSOC);
				$services = $q->fetchAll();
?>
				<div class="row">

					<?php
				foreach ($services as $service_index => $service) {?>
					<div class="col-md-6">


						<div class="d-flex align-items-baseline myh3" style="gap:15px">
							<input
								<?=isset($_POST['subreserve']) && (!$success) && in_array($service['id'],isset($_POST['service_ids'])?$_POST['service_ids']:[])?"checked":""?>
								onchange="calculateFinalPrice()" type="checkbox" name="service_ids[]"
								id="service<?=$service_index?>" value='<?=$service['id']?>' class="service-checkbox"
								data-price="<?=$service['added_price']?>">
							<label for='service<?=$service_index?>'>
								<img width="25" src="icons/<?= $service['icon'] ?>" />
								<!-- <div> -->
								<?=$service['description']?> -
								<?=$service['added_price']?> BD
								<!-- </div> -->

							</label>
						</div>
					</div>
					<?php } ?>
				</div><br>
				<div class="row">
					<div class="col-md-6">

						<h3 class="myh3">Choose a Date:</h3>
                        
						<input type="date" id="date" name="date" min="<?php echo date("Y-m-d"); ?>"
							value="<?=isset($_POST['subreserve']) && (!$success)?$_POST['date']:""?>">
					</div>
					<div class="col-md-6">
						<h3 class="myh3">Choose a timing:</h3>
						<div>
							<input type="radio" name="timing" id="timin1" value="5am - 1pm"
								<?=isset($_POST['subreserve']) && (!$success)?(isset($_POST['timing'])?$_POST['timing']:"") =="5am - 1pm"?"checked":"":""?>><label
								for="timin1">5am -
								1pm</label>
						</div>
						<div>

							<input type="radio" name="timing" id="timin2" value="5pm - 1am"
								<?=isset($_POST['subreserve']) && (!$success)?(isset($_POST['timing'])?$_POST['timing']:"") =="5pm - 1am"?"checked":"":""?>><label
								for="timin2">5pm - 1am</label>
						</div>

					</div>
				</div>
				<br />
				<div class="row">
					<div class="col-md-6">
						<h3 class="myh3">Map Location :</h3>
						<input class="w-100" type="text" id="location" name="location" placeholder="Location URL"
							value="<?=isset($_POST['subreserve']) && (!$success)?$_POST['location']:""?>" />
					</div>
					<div class="col-md-6">
						<h3 class="myh3">Specify Place :</h3>
						<input class="w-100" type="text" id="place" name="place" placeholder="Where is your place"
							value="<?=isset($_POST['subreserve']) && (!$success)?$_POST['place']:""?>" />
					</div>
				</div>
				<br /><br />
				<h3 class="myh3">Final Price : </h3>
				<b class="final-price">
					<?=$kashta['price']?> BD
				</b> <br /><br />
				<input type="hidden" name="finalPrice">

				<input type="submit" class="btn btn-primary" name="subreserve" value="Reserve">
				<a href="view.php?kashta_id=<?=$kashta['id']?>" class="btn btn-primary">Back</a>
			</ul>
		</form>
	</div>

	</div>
	</div>
	<div class="modal fade" id="expanded-images" tabindex="-1" role="dialog" aria-labelledby="expanded-imagesLabel"
		aria-hidden="true">
		<div class="modal-dialog" role="document">
			<div class="modal-content">
				<div class="modal-header">
					<h5 class="modal-title" id="expanded-imagesLabel">
						Image
					</h5>
					<button type="button" class="close" data-dismiss="modal" aria-label="Close">
						<span aria-hidden="true">&times;</span>
					</button>
				</div>
				<div class="modal-body">
					<div class="full-image"></div>
				</div>
				<div class="modal-footer">
					<button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>

				</div>
			</div>
		</div>
	</div>
</body>
<script src="reservation.js"></script>
<?php
if(isset($_POST['subreserve']) && (!$success)){
?>
<script>
calculateFinalPrice();
</script>
<?php
}
?>
<script src="view.js"></script>

<?php include 'footer.php'; ?>

</html>