<?php include 'header.php';?>
<!DOCTYPE html>
<html lang="en">

<head>
	<meta charset="UTF-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<title>Document</title>
	<link rel="stylesheet" href="S_1.css">
</head>

<body>
	<main>
		<div class="hero">
			<div class="herobox1">
				<img src="logo1r.png" width=300 height=auto>
			</div>
			<div class="herobox2">
				<h3>Privacy Policy:-</h3>
				<p>This Privacy Policy provides the manner your data is collected and used by extra. You are advised to read this Privacy Policy carefully. By accessing the services provided by extra.com you agree to the collection and use of your data by extra.com and certain authorized third party service providers in the manner provided in this Privacy Policy. If you do not agree with this Privacy Policy, please do not use the website – extra.com. By accepting the Privacy Policy during registration, you expressly consent to our use and disclosure of your personal information in accordance with this Privacy Policy. This Privacy Policy is incorporated into and subject to the terms of the User Agreement.
				</p>
				</p>
			</div>
		</div>
	</main>

</body>
<?php include 'footer.php';?>

</html>