<?php
// This serves as a login guard for all of the pages that navigate you to the login page if you're
// not signed in.

session_start();
if(!isset($_SESSION['login_user'])){
header('Location:login.php');
}
?>