<html>


<?php include 'header.php'; ?>

<head>
	<title> Login </title>
</head>

<body>
	<div class="welcome_fade">

	</div>
	<main>

		<div class="container-login">
			<h1 style="color:#776559"> Sign in</h1><br />

			<form autocomplete="off" action="<?php echo $_SERVER['PHP_SELF']; ?>" method="POST">

				<div class="form-group ">
					<label for="username">Username</label>
					<input autocomplete="off" type="text" class="form-control" id="username" name="username">
				</div>
				<div class="form-group ">
					<label for="password">Password</label>
					<input autocomplete="off" type="password" class="form-control" id="password" name="password">
					<!-- <a href="forgetpassword.php"> forget password</a> -->
				</div>
				<input type="hidden" name="login" />
				<button class="btn btn-primary">
					Sign in
				</button>
				<?php
			echo "</br></br>";
				if(isset($_POST['login'])){
					$q = $db->prepare('select * from users where username = :username and password = :password');
					$q->bindParam(':username', $_POST['username']);
					$q->bindParam(':password', hash('md5', $_POST['password']));
					$q->execute();
			
					$q->setFetchMode(PDO::FETCH_ASSOC);
					$users = $q->fetchAll();
					if(count($users)){
						$_SESSION['login_user'] = $users[0];
						header("Location:index.php");
					}else{
						echo"<h6>Invalid username or password.</h6>";
					}
				}
			?>
				<h6> No account? <a href="signup.php">Create account</a></h6>
			</form>

		</div>
	</main>


</body>
<script>
setTimeout(() => {
	$('.welcome_fade').fadeOut(850)

}, 850);
</script>
<?php include 'footer.php'; ?>

</html>