function filterKashtat() {
  setTimeout(() => {
    $.ajax({
      type: "POST",
      url: "get-kashtat.php",
      data: JSON.stringify({ query: $(`[name="searchtxt"]`).val() }),
      headers: {
        "Content-Type": "application/json; charset=utf-8",
        Accept: "*/*",
      },
      dataType: "json",
      success: function (response) {
        msg(response?.message);
        // console.log(response);
        // $(".kasta-col").hide();
        $(".container .row").html(``);
        response.kashtat.forEach((kashta, kid) => {
          var ratingContent = ``;
          for (let index = 0; index < 5; index++) {
            ratingContent += `<div class="starx ${kashta.averagefloored >= index + 1 ? "hovereffect" : ""}">
			<i class="fa fa-star" aria-hidden="true"></i>
		</div>`;
          }

          ratingContent += `<div>(${kashta.average})</div>`;

          $(".container .row").append(`
		  <div class="col-12 my-sm-2 col-md-6 col-lg-4 kasta-col" id="kashta_${kashta.id}">
		  <div class="card card1" style="width: 18rem;">
			  <!-- <img src="Kashta Pics/kashta6/k61.jpeg" class="card-img-top" alt="kashta1"> -->

			  <div id="carousel${kashta.id}" class="carousel slide" data-ride="carousel" data-interval="${kid * 1000 + 2000}">
				<ol class="carousel-indicators">
				  ${kashta.kashta_images
            .map((image, index) => `<li data-target="#carousel${kashta.id}" data-slide-to="${index}" class="${index === 0 ? "active" : ""}"></li>`)
            .join("\n")}
				</ol>
				  <div class="carousel-inner">
				  ${kashta.kashta_images
            .map(
              (image, index) => `
					<div class="carousel-item ${index === 0 ? "active" : ""}">
						<div class="kashta-image w-100" style="background-image:url('Kashta Pics/${kashta.id}/${image.filename}')">
						</div>
					</div> 
				  `
            )
            .join("\n")}
			</div>
				  <a class="carousel-control-prev" href="#carousel${kashta.id}" role="button" data-slide="prev">
					  <span class="carousel-control-prev-icon" aria-hidden="true"></span>
					  <span class="sr-only">Previous</span>
				  </a>
				  <a class="carousel-control-next" href="#carousel${kashta.id}" role="button" data-slide="next">
					  <span class="carousel-control-next-icon" aria-hidden="true"></span>
					  <span class="sr-only">Next</span>
				  </a>
			  
			  </div>
			  <div class="card-body">
				  <div class="d-flex justify-content-between align-items-center" style="gap:10px;">
					  <div>
						  <h4 class="card-title" style="color:#776559"><b>${kashta.name}</b> </h4>
						  <div>${kashta.description}</div>
						  <div>Starting at <b>${kashta.price} BD</b></div>
						  <div>
							  <div class="stars-container">
							  ${ratingContent}
							  </div>
						  </div>
					  </div>
					  <div>
						  <a href="view.php?kashta_id=${kashta.id}" class="btn btn-primary b1 stretched-link">View</a>
					  </div>
				  </div>
			  </div>
		  </div>
	  </div>
		  `);
        });
        $(`[data-ride="carousel"]`).carousel("cycle");
      },
      error: function (response) {
        msg(response?.responseJSON?.message);
        $("html, body").animate(
          {
            scrollTop: 0,
          },
          500
        );
      },
      complete: function (data) {},
    });
  }, 500);
}
