function file_change(e) {
  $(`.image-upload-container`).html(``);

  var li = ``;
  var carouselitem = ``;

  [...e.target.files].forEach((element, index) => {
    var src = URL.createObjectURL(element);
    carouselitem += `<img width="60" src="${src}">`;
  });

  $(`.image-upload-container`).html(carouselitem);
}
