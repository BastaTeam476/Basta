<?php include 'header.php';?>
<?php
if(isset($_GET["reserve_id"])){
    echo $_GET["reserve_id"];
}
 ?>
<!DOCTYPE html>
<html lang="en">

<head>
	<meta charset="UTF-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<title>Document</title>
	<link rel="stylesheet" href="S_1.css">
</head>

<body>
	<div class="card">
		<div id="carouselExampleIndicators" class="carousel slide" data-ride="carousel">
			<ol class="carousel-indicators">
				<li data-target="#carouselExampleIndicators" data-slide-to="0" class="active"></li>
				<li data-target="#carouselExampleIndicators" data-slide-to="1"></li>
				<li data-target="#carouselExampleIndicators" data-slide-to="2"></li>
			</ol>

			<div class="carousel-inners h-50" style="border-radius: 30%; align-item: center;">
				\\if(isset($_POST['k1']){
				<div class="carousel-item active">
					<img class="d-block w-100  " src="./Kashta Pics/kashta6/k61.jpeg" alt="First slide">
				</div>
				<div class="carousel-item">
					<img class="d-block w-100" src="./Kashta Pics/kashta6/k62.jpeg" alt="Second slide">
				</div>
				<div class="carousel-item">
					<img class="d-block w-100" src="./Kashta Pics/kashta6/k63.jpeg" alt="Third slide">
				</div>
				<div class="carousel-item">
					<img class="d-block w-100" src="./Kashta Pics/kashta6/k64.jpeg" alt="Third slide">
				</div>
			</div>
			\\}
			<a class="carousel-control-prev" href="#carouselExampleIndicators" role="button" data-slide="prev">
				<span class="carousel-control-prev-icon" aria-hidden="true"></span>
				<span class="sr-only">Previous</span>
			</a>
			<a class="carousel-control-next" href="#carouselExampleIndicators" role="button" data-slide="next">
				<span class="carousel-control-next-icon" aria-hidden="true"></span>
				<span class="sr-only">Next</span>
			</a>
		</div>

		<div class="comments">
			<p>
			<ul><b class="h4"> Reviews </b>
				<li>The basta was nice, it look like the photos</li>
				<li>It was really great Basta , I will deal with you again and I advise everyone to book it now</li>
				<li>The price was suitable with the Services , love you soo much XOXO </li>
			</ul><br />
			</p>
		</div>



		<div class="reservbotton">
			<a href="view.php"><button type="" class="btn btn-primary">Back to view</button></a>

		</div>

	</div>

</body>

</html>