<?php
echo date('Y-m-d') > "2022-12-07";