<?php
include_once('connection.php');
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}
header('Content-type: application/json');

$kashtat = [];
try { 
$post = file_get_contents('php://input');
$d = json_decode($post,true);
$msg = "No data received.";
 if(isset($d['query'])){

	$errors = [];

	if(!preg_match("/^[a-zA-Z ]+$/i", $d['query'])){
		// $errors[]="Search text may only contain letters and spaces.";
	}
	
	if(count($errors)){
		$msg = "";
		foreach ($errors as $key => $value) {
			$msg.= "$value\n";
		}
		http_response_code(500);
	}else{
		$q = $db->prepare('SELECT * FROM `kashta`'.($d['query'] != ""?'where name like ? or description like ? ':""));
		if($d['query'] !=""){
			$q->execute(["%".$d['query']."%","%".$d['query']."%"]);
		}else{
			$q->execute();
		}
		$q->setFetchMode(PDO::FETCH_ASSOC);
		$kashtat = $q->fetchAll();
		foreach ($kashtat as $i => $kashta) {
			$q = $db->prepare('select * from kashta_images where kashta_id = :id');
			$q->bindParam(':id', $kashta['id']);
			$q->execute();
	
			$q->setFetchMode(PDO::FETCH_ASSOC);
			$kashta_images = $q->fetchAll();
			$kashtat[$i]['kashta_images'] = $kashta_images;


			$q = $db->prepare('select rating.*, users.username as `name`, users.profile_image as `img` from rating left join users on users.id = rating.user_id where kashta_id = :kashta_id ORDER BY `rating`.`id` DESC');
			$q->bindParam(':kashta_id', $kashta['id']);
			$q->execute();
	
			$q->setFetchMode(PDO::FETCH_ASSOC);
			$ratings = $q->fetchAll();

			$rate_sum = 0;

			foreach ($ratings as $key => $rate) {
				$rate_sum += $rate['stars'];
			}
			$average = $rate_sum >= 1?round(($rate_sum / count($ratings)), 1):0;
			$averagefloored = floor($average);
			$kashtat[$i]['ratings'] = $ratings;
			$kashtat[$i]['average'] = $average;
			$kashtat[$i]['averagefloored'] = $averagefloored;
		}
		$msg = "Retreived ".count($kashtat)." kashtat.";
	}
}
} catch(Exception $e) {
	http_response_code(500);
	$msg = $e->getMessage().$e->getTraceAsString();
}
echo json_encode(array("message"=>$msg,"kashtat"=>$kashtat));