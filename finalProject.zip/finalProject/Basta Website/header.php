<?php
include_once('connection.php');
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}
?>

<head>
	<meta charset="UTF-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1.0, shrink-to-fit=no">
	<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/css/bootstrap.min.css"
		integrity="sha384-xOolHFLEh07PJGoPkLv1IbcEPTNtaed2xpHsD9ESMhqIYd0nLMwNLD69Npy4HI+N" crossorigin="anonymous">
	<script src="https://kit.fontawesome.com/5d35b2cf51.js" crossorigin="anonymous"></script>

	<link rel="icon" type="image/x-icon" href="favico.PNG">
	<link rel="stylesheet" href="S_1.css">
	<script src="https://cdn.jsdelivr.net/npm/jquery@3.6.2/dist/jquery.min.js">
	</script>
	<script src="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/js/bootstrap.bundle.min.js"
		integrity="sha384-Fy6S3B9q64WdZWQUiU+q4/2Lc9npb8tCaSX9FK7E8HnRr0Jz8D6OP9dO5Vg3Q9ct" crossorigin="anonymous">
	</script>
	<title>Basta</title>
</head>


<nav class="main-navbar">

	<div class="d-flex gap-3 align-items-center">
		<a href="index.php">
			<img width="200" id="q1111" src="logo1r.png" alt="logo">
		</a>




	</div>
	<div class="poriflew">

		<?php
if(isset($_SESSION['login_user'])){
?>
		<div class="d-flex align-items-center" style="gap: 10px;">
			<?php if(!str_contains($_SERVER['REQUEST_URI'],"index")){ ?>
			<form class="searchForm" style="margin: 0;" action="index.php">
				<?php }  ?>
				<input <?=str_contains($_SERVER['REQUEST_URI'],"index")?"onkeyup=filterKashtat()":""?>
					value="<?=isset($_GET['searchtxt'])?$_GET['searchtxt']:""?>" class="form-control searchinggg mr-sm-2"
					type="search" name="searchtxt" placeholder="Search" aria-label="Search">
				<?php if(!str_contains($_SERVER['REQUEST_URI'],"index")){ ?>
			</form>

			<?php }  ?>
			<a href="#"
				onclick="searchKashtat(event,<?=!str_contains($_SERVER['REQUEST_URI'],"index")?"true":"false"?>)"
				class="h-icon" data-toggle="tooltip" data-placement="top" title="Search Kashtat"> <i
					class="fa-solid fa-search fa-2x searchingg"> </i> </a>
			<a href="index.php" class="h-icon"> <i class="fa-solid fa-house-chimney fa-2x househome " data-toggle="tooltip"
					data-placement="top" title="Home"> </i> </a>
			<?php if($_SESSION['login_user']['is_admin']){ ?>
			<a href="add-update-kashta.php" class="h-icon"> <i class="fa-solid fa-plus fa-2x" data-toggle="tooltip"
					data-placement="top" title="Add a Kashta"> </i> </a>
			<?php } ?>


			<div class="dropdown">
				<a data-toggle="dropdown" href="#" class="profileLink">
					<!-- <i class="fa-solid fa-circle-user fa-2x ml-2"></i> -->
					<div>
						<?php
							if($_SESSION['login_user']['profile_image']){
						?>
						<div class="profile-image-show"
							style="background-image:url('<?php echo "ProfileImages/".$_SESSION['login_user']['profile_image'] ?>')">
						</div>
						<?php
							}else{
						?>
						<div></div>
						<?php
							}
						?>

					</div>
					<div class="non-mob"><?php echo $_SESSION['login_user']['username'] ?></div>
					<div></div>
				</a>
				<div class="dropdown-menu user-dropdown">
					<a class="dropdown-item" href="user-profile.php">User Profile</a>
					<a class="dropdown-item" href="bookings.php">Bookings</a>
					<!-- <a class="dropdown-item" href="#">Another action</a> -->
					<div class="dropdown-divider"></div>
					<a class="dropdown-item" href="logout.php">Logout</a>
				</div>
			</div>
		</div>
		<?php
}
?>

		<?php
if(isset($_SESSION['login_user'])){
?>


		<!-- <button class="btn btn-outline-success my-2 my-sm-0" type="submit">Search</button> -->
		<div class="icon heading-icons">

		</div>
		<?php
}
?>
	</div>





</nav>
<script src="header.js"></script>
<div aria-live="polite" aria-atomic="true" style="position: relative; min-width:200px;">
	<div class="toast" style="position: absolute; top: 0; right: 0; width: 250px;     z-index: 888;" data-delay="4500">
		<div class="toast-header">
			<!-- <img src="..." class="rounded mr-2" alt="..."> -->
			<strong class="mr-auto">System</strong>
			<!-- <small>11 mins ago</small> -->
			<button type="button" class="ml-2 mb-1 close" data-dismiss="toast" aria-label="Close">
				<span aria-hidden="true">&times;</span>
			</button>
		</div>
		<div class="toast-body">
			Hello, world! This is a toast message.
		</div>
	</div>
</div>