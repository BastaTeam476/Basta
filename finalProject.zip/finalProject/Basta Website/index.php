<?php include 'login.guard.php' ?>


<html>

<?php include 'header.php'; ?>
<?php //Comment here ?>

<body>
	<main>
		<div class="container">
			<div class="row my-md-3 my-lg-3">

				<?php
				// $search = isset($_GET['searchtxt']);
				$q = $db->prepare("select * from kashta"/*.($search?" where name like ? or description like ?":"")*/);
			// if($search){
				// $q->execute(["%".$_GET['searchtxt']."%","%".$_GET['searchtxt']."%"]);
			// }else{
				$q->execute();
			// }
	
			$q->setFetchMode(PDO::FETCH_ASSOC);
			$kashtat = $q->fetchAll();

			foreach ($kashtat as $kashta_index => $kashta) {

				$q = $db->prepare('select * from kashta_images where kashta_id = :id');
				$q->bindParam(':id', $kashta['id']);
				$q->execute();
		
				$q->setFetchMode(PDO::FETCH_ASSOC);
				$kashta_images = $q->fetchAll();

				?>

				<div class="col-12- my-sm-2 col-md-6 col-lg-4 kasta-col bastagw " id="kashta_<?=$kashta['id']?>">
					<div class="card1">
						<!-- <img src="Kashta Pics/kashta6/k61.jpeg" class="card-img-top" alt="kashta1"> -->

						<div id="<?="carousel".$kashta['id']?>" class="carousel slide" data-ride="carousel"
							data-interval="<?=($kashta_index*1000)+2000?>">
							<ol class="carousel-indicators">
								<?php foreach ($kashta_images as $img_index => $image) { ?>
								<li data-target="#<?="carousel".$kashta['id']?>" data-slide-to="<?=$img_index?>"
									<?=$img_index==0?"class='active'":""?>></li>
								<?php } ?>
							</ol>
							<div class="carousel-inner">
								<div class="capacityrange">
									<i class="fa fa-user"></i> <?=$kashta['min_capacity']?> -
									<?=$kashta['max_capacity']?>
								</div>
								<?php foreach ($kashta_images as $img_index => $image) { ?>
								<div class="carousel-item <?=$img_index==0?"active":""?>">

									<div class="kashta-image w-100"
										style="background-image:url('Kashta Pics/<?=$kashta['id']."/".$image['filename']?>')">
									</div>
								</div>
								<?php } ?>
							</div>
							<a class="carousel-control-prev" href="#<?="carousel".$kashta['id']?>" role="button"
								data-slide="prev">
								<span class="carousel-control-prev-icon" aria-hidden="true"></span>
								<span class="sr-only">Previous</span>
							</a>
							<a class="carousel-control-next" href="#<?="carousel".$kashta['id']?>" role="button"
								data-slide="next">
								<span class="carousel-control-next-icon" aria-hidden="true"></span>
								<span class="sr-only">Next</span>
							</a>
						</div>
						<div class="card-body">
							<div class="d-flex justify-content-between align-items-center" style="gap:10px;">
								<div>
									<h4 class="card-title" style="color:#776559"><b><?= $kashta['name'] ?></b> </h4>
									<div>
										<?= $kashta['description'] ?>
									</div>
									<div>
										Starting at <b><?= $kashta['price'] ?> BD</b>
									</div>
									<div>

										<div class="stars-container">

											<?php
			$q = $db->prepare('select rating.*, users.username as `name`, users.profile_image as `img` from rating left join users on users.id = rating.user_id where kashta_id = :kashta_id ORDER BY `rating`.`id` DESC');
			$q->bindParam(':kashta_id', $kashta['id']);
			$q->execute();
	
			$q->setFetchMode(PDO::FETCH_ASSOC);
			$ratings = $q->fetchAll();

			$rate_sum = 0;

			foreach ($ratings as $key => $rate) {
				$rate_sum += $rate['stars'];
			}
			$average = $rate_sum >= 1?round(($rate_sum / count($ratings)), 1):0;
			$averagefloored = floor($average);
			
for ($i=0; $i < 5; $i++) { 
	?>
											<div class="starx <?=$averagefloored >= ($i+1)?"hovereffect":""?>">
												<i class="fa fa-star"></i>
											</div>
											<?php
}
?>
											<div>
												(<?=$average?>)
											</div>
										</div>
									</div>
								</div>
								<div>
									<a href="view.php?kashta_id=<?=$kashta['id']?>"
										class="btn btn-primary b1 stretched-link">View</a>

								</div>
							</div>
						</div>
					</div>
				</div>
				<?php } ?>

			</div>
		</div>
	</main>
</body>

<?php include 'footer.php'; ?>
<?php if(isset($_GET['searchtxt'])){ ?>
<script>
setTimeout(() => {
	filterKashtat()
}, 450);
</script>
<?php } ?>
<script src="index.js"></script>

</html>