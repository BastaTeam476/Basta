-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Dec 28, 2022 at 10:35 PM
-- Server version: 10.4.25-MariaDB
-- PHP Version: 8.1.10

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `basta`
--

-- --------------------------------------------------------

--
-- Table structure for table `booking`
--

CREATE TABLE `booking` (
  `id` int(11) NOT NULL,
  `date` varchar(255) NOT NULL,
  `timing` varchar(255) NOT NULL,
  `location` text NOT NULL,
  `place` varchar(255) NOT NULL DEFAULT '',
  `kashta_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `booking`
--

INSERT INTO `booking` (`id`, `date`, `timing`, `location`, `place`, `kashta_id`, `user_id`) VALUES
(3, '2022-12-07', '5pm - 1am', 'https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d14312.065955809043!2d50.626560000000005!3d26.26112825!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x3e49a8a0703f80a9%3A0x72566873cc23a61b!2z2LLZhtis2KjYp9ix2Yog2YLZhdio2LEgUWFtYmFyIFN3ZWV0c2hvcA!5e0!3m2!1sen!2sbh!4v1672043457884!5m2!1sen!2sbh', 'Sakheer', 8, 2),
(4, '2022-12-22', '5am - 1pm', 'https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d88354.362344573!2d50.47600307071997!3d26.174882961906597!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x3e49b146223d5fdb%3A0x209d755c800288bc!2sAl%20Liwan!5e0!3m2!1sen!2sbh!4v1672043524444!5m2!1sen!2sbh', 'Saar', 9, 2),
(6, '2022-11-30', '5am - 1pm', 'https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d14325.289736920364!2d50.575266438040615!3d26.15362659617196!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x3e49ac21e500250b%3A0xde5acb7fa1e48c8a!2sGulf%20University!5e0!3m2!1sen!2sbh!4v1672043566691!5m2!1sen!2sbh', 'Kahoona', 11, 2),
(7, '2022-12-29', '5am - 1pm', 'https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d4258.832724084782!2d50.517522430971724!3d26.156404321162647!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x3e49af32f1c5369b%3A0x1d1aed5800911f0e!2z2YLYsdi32KfYs9mK2Kkg2YXYtNin2LHZgg!5e0!3m2!1sen!2sbh!4v1672043590563!5m2!1sen!2sbh', 'Hayar', 13, 2),
(8, '2022-12-27', '5am - 1pm', 'https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3578.8405755447197!2d50.5569096399646!3d26.234369172616304!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x3e49a5788e4fa6d3%3A0x59a12e7b22b7b68c!2sCity%20Centre%20Bahrain!5e0!3m2!1sen!2sbh!4v1672058098281!5m2!1sen!2sbh', 'Manama', 15, 10),
(9, '2022-12-31', '5pm - 1am', 'https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3578.8405755447197!2d50.5569096399646!3d26.234369172616304!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x3e49a5788e4fa6d3%3A0x59a12e7b22b7b68c!2sCity%20Centre%20Bahrain!5e0!3m2!1sen!2sbh!4v1672058098281!5m2!1sen!2sbh', 'Manama', 18, 10),
(10, '2022-12-28', '5am - 1pm', 'https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3578.8405755447197!2d50.5569096399646!3d26.234369172616304!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x3e49a5788e4fa6d3%3A0x59a12e7b22b7b68c!2sCity%20Centre%20Bahrain!5e0!3m2!1sen!2sbh!4v1672058098281!5m2!1sen!2sbh', 'Manama', 19, 10),
(11, '2023-01-06', '5am - 1pm', 'https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3578.8405755447197!2d50.5569096399646!3d26.234369172616304!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x3e49a5788e4fa6d3%3A0x59a12e7b22b7b68c!2sCity%20Centre%20Bahrain!5e0!3m2!1sen!2sbh!4v1672058098281!5m2!1sen!2sbh', 'Manama', 20, 11),
(12, '2022-12-30', '5am - 1pm', 'https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3578.8405755447197!2d50.5569096399646!3d26.234369172616304!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x3e49a5788e4fa6d3%3A0x59a12e7b22b7b68c!2sCity%20Centre%20Bahrain!5e0!3m2!1sen!2sbh!4v1672058098281!5m2!1sen!2sbh', 'Manama', 13, 11),
(13, '24-12-2022', '5am-1pm', 'https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3578.832593056331!2d50.5522912505847!3d26.23462849518498!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x3e49a5788e4fa6d3%3A0x59a12e7b22b7b68c!2sCity%20Centre%20Bahrain!5e0!3m2!1sen!2sbh!4v1672167797319!5m2!1sen!2sbh', 'manama', 19, 11),
(14, '2023-01-12', '5pm - 1am', 'https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3578.8405755447197!2d50.5569096399646!3d26.234369172616304!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x3e49a5788e4fa6d3%3A0x59a12e7b22b7b68c!2sCity%20Centre%20Bahrain!5e0!3m2!1sen!2sbh!4v1672058098281!5m2!1sen!2sbh', 'Manama', 17, 11),
(15, '2022-12-28', '5pm - 1am', 'https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3578.8405755447197!2d50.5569096399646!3d26.234369172616304!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x3e49a5788e4fa6d3%3A0x59a12e7b22b7b68c!2sCity%20Centre%20Bahrain!5e0!3m2!1sen!2sbh!4v1672058098281!5m2!1sen!2sbh', 'Manama', 8, 12),
(16, '2023-01-21', '5pm - 1am', 'https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3578.8405755447197!2d50.5569096399646!3d26.234369172616304!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x3e49a5788e4fa6d3%3A0x59a12e7b22b7b68c!2sCity%20Centre%20Bahrain!5e0!3m2!1sen!2sbh!4v1672058098281!5m2!1sen!2sbh', 'Manama', 17, 11);

-- --------------------------------------------------------

--
-- Table structure for table `booking_services`
--

CREATE TABLE `booking_services` (
  `id` int(11) NOT NULL,
  `booking_id` int(11) NOT NULL,
  `service_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `booking_services`
--

INSERT INTO `booking_services` (`id`, `booking_id`, `service_id`) VALUES
(3, 3, 1),
(4, 3, 3),
(5, 3, 5),
(6, 4, 1),
(7, 4, 2),
(8, 4, 5),
(9, 4, 6),
(10, 5, 1),
(11, 5, 2),
(12, 5, 3),
(13, 5, 7),
(14, 6, 4),
(15, 6, 5),
(16, 7, 1),
(17, 7, 2),
(18, 8, 1),
(19, 8, 2),
(20, 9, 3),
(21, 9, 4),
(22, 9, 7),
(23, 10, 7),
(24, 12, 4),
(25, 16, 4),
(26, 16, 7);

-- --------------------------------------------------------

--
-- Table structure for table `comments`
--

CREATE TABLE `comments` (
  `id` int(11) NOT NULL,
  `kashta_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `description` varchar(255) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `comments`
--

INSERT INTO `comments` (`id`, `kashta_id`, `user_id`, `description`, `created_at`) VALUES
(6, 8, 2, 'test', '2022-12-20 10:31:41'),
(8, 8, 2, 'Hello world', '2022-12-20 10:50:20'),
(9, 11, 2, 'Very good booking', '2022-12-21 05:16:09'),
(10, 19, 11, 'I recommend you all to reserve that basta we had memorable time', '2022-12-27 19:06:26'),
(11, 19, 11, 'That basta is wonderful', '2022-12-27 19:08:34'),
(12, 15, 10, 'I recommend no one to go there', '2022-12-28 12:51:03'),
(13, 8, 2, 'it was a beautiful place to visit', '2022-12-28 19:35:35'),
(14, 9, 2, 'It is Good but I think they have to put a big umbrella for the raining weather ', '2022-12-28 19:41:36');

-- --------------------------------------------------------

--
-- Table structure for table `customer`
--

CREATE TABLE `customer` (
  `id` int(11) NOT NULL,
  `first_name` varchar(255) NOT NULL,
  `last_name` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `customer`
--

INSERT INTO `customer` (`id`, `first_name`, `last_name`) VALUES
(5, 'Payato', 'Langagyay'),
(6, 'sdfsd', 'fsdfs'),
(7, 'Mariam', 'Ali'),
(8, 'zainab', 'nasser'),
(9, 'zahraa', 'sayed'),
(10, 'fatima', 'Hasan');

-- --------------------------------------------------------

--
-- Table structure for table `kashta`
--

CREATE TABLE `kashta` (
  `id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `description` varchar(255) NOT NULL,
  `price` int(11) NOT NULL,
  `min_capacity` int(11) NOT NULL,
  `max_capacity` int(11) NOT NULL,
  `admin_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `kashta`
--

INSERT INTO `kashta` (`id`, `name`, `description`, `price`, `min_capacity`, `max_capacity`, `admin_id`) VALUES
(8, 'Kashtalux', 'That Kashta is specialized for elegant gatherings', 100, 21, 50, 2),
(9, 'Kashta Tours', 'That kashta suits kids gatherings where they could play in a large zone', 33, 10, 20, 2),
(11, 'Kashta Time', 'That kashta suits the matches days where it has a large capacity', 43, 35, 80, 2),
(12, 'Gathering Time', 'That kashta is specialized for old peoples gatherings ', 89, 25, 50, 2),
(13, 'The Gorgeous Kashta', 'That Kashta is specialized for elegant gatherings', 50, 24, 40, 2),
(15, 'Magnificent Basta ', 'That kashta suits kids gatherings where they could play in a large zone', 70, 11, 20, 2),
(17, 'Kashta three', 'That kashta suits kids gatherings where they could play in a large zone', 48, 5, 8, 2),
(18, 'kashta four', 'That kashta is specialized for old peoples gatherings ', 30, 6, 7, 2),
(19, 'kashta five', 'That kashta suits kids gatherings where they could play in a large zone', 36, 5, 30, 2),
(20, 'kashtatna', 'That kashta is specialized for old peoples gatherings ', 55, 10, 15, 2),
(21, 'Marvelous Basta', 'That kashta suits kids gatherings where they could play in a large zone', 46, 12, 23, 2),
(24, 'Alnoor Kashta', 'That Kashta is specialized for elegant gatherings', 20, 4, 10, 2);

-- --------------------------------------------------------

--
-- Table structure for table `kashta_images`
--

CREATE TABLE `kashta_images` (
  `id` int(11) NOT NULL,
  `filename` varchar(255) NOT NULL,
  `kashta_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `kashta_images`
--

INSERT INTO `kashta_images` (`id`, `filename`, `kashta_id`) VALUES
(6, '16714649591c650297c15da454855246f5010cfa97.jpg', 8),
(7, '16714649592c6ff8dfbcd96283e025ca6186587743.jpg', 8),
(8, '1671464959027df8c50d800853f85ae6bfd7ab5d4a.jpg', 8),
(9, '167146495950e7aac006c594aba8aa45d02a8b107d.jpg', 8),
(11, '16714750469c2afa2a5d8fac3b14b820221319280f.jpg', 9),
(12, '1671475046ec2d56f87114092e7a7d8502f610cace.jpg', 9),
(14, '16714750890fe7686b79eb50ede4132c8370bbee5d.jpg', 10),
(16, '167147511335e309c70ced2682831e97167e6c99af.jpg', 11),
(17, '167147511336d485c632341cb11b143822fce80483.jpg', 11),
(19, '16714751336d6a748662030cc68b19e463700bc035.jpg', 12),
(20, '16714751337b2fbb06bff18e07a99e4c7369b6e58c.jpg', 12),
(21, '167147513311.jpg', 12),
(23, '1671475164k61.jpeg', 13),
(24, '1671475164k62.jpeg', 13),
(25, '1671475164k63.jpeg', 13),
(26, '1671475164k64.jpeg', 13),
(32, '16720562761112.jpg', 15),
(33, '16720562761113.jpg', 15),
(35, '16720568522221.jpg', 17),
(36, '16720568522222.jpg', 17),
(37, '16720568522223.jpg', 17),
(38, '16720568522224.jpg', 17),
(39, '16720572633331.jpg', 18),
(40, '16720572633332.jpg', 18),
(41, '16720572633333.jpg', 18),
(42, '16720572633334.jpg', 18),
(43, '16720572974441.jpg', 19),
(44, '16720572974442.jpg', 19),
(45, '16720572974443.jpg', 19),
(46, '16720572974444.jpg', 19),
(47, '16720575315551.jpg', 20),
(48, '16720575315552.jpg', 20),
(49, '16720575315553.jpg', 20),
(50, '16720575315554.jpg', 20),
(52, '16720575586662.jpg', 21),
(53, '16720575586663.jpg', 21),
(54, '16720575586664.jpg', 21),
(57, '1672176781Screenshot 2022-11-06 153133.png', 24),
(58, '1672176781Screenshot 2022-11-06 153322.png', 24),
(59, '1672176781Screenshot 2022-11-06 153350.png', 24);

-- --------------------------------------------------------

--
-- Table structure for table `kashta_services`
--

CREATE TABLE `kashta_services` (
  `id` int(11) NOT NULL,
  `description` varchar(255) NOT NULL,
  `icon` varchar(255) NOT NULL,
  `added_price` double NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `kashta_services`
--

INSERT INTO `kashta_services` (`id`, `description`, `icon`, `added_price`) VALUES
(1, 'Grilling', 'bbq.png', 50),
(2, 'Coffee Corner', 'coffee.png', 20),
(4, 'Gaming', 'console.png', 10),
(5, 'DJ', 'dj.png', 20),
(6, 'pillows and blankets', 'pillows.png', 5),
(7, 'Movies', 'video-camera.png', 20);

-- --------------------------------------------------------

--
-- Table structure for table `rating`
--

CREATE TABLE `rating` (
  `id` int(11) NOT NULL,
  `kashta_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `stars` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `rating`
--

INSERT INTO `rating` (`id`, `kashta_id`, `user_id`, `stars`) VALUES
(1, 8, 2, 4),
(4, 19, 11, 5),
(7, 15, 10, 1);

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `username` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `phone` int(11) NOT NULL,
  `email` varchar(255) NOT NULL,
  `profile_image` varchar(255) DEFAULT NULL,
  `customer_id` int(11) DEFAULT NULL,
  `is_admin` tinyint(1) DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `username`, `password`, `phone`, `email`, `profile_image`, `customer_id`, `is_admin`) VALUES
(2, 'admin', 'e10adc3949ba59abbe56e057f20f883e', 36602112, 'admin@admin.com', '1671460936admin.jpg', NULL, 1),
(7, 'Mariam', '202cb962ac59075b964b07152d234b70', 35502112, 'mariam123@hotray.com', '1671438784p3.jpeg', 5, 0),
(8, 'Narjis', 'e10adc3949ba59abbe56e057f20f883e', 36656653, '1234narjis@sdfsdf.com', '1672057946defaultprofile.jpg', 6, 0),
(9, 'Huda', '73882ab1fa529d7273da0db6b49cc4f3', 23321216, 'hudahuda@dsfsdf.com', '1672122683defaultprofile.jpg', 7, 0),
(10, 'Zainab', '85aed1989658b6c6ae011fa81a4e456d', 47287251, 'zainab@gmail.com', '1672122299defaultprofile.jpg', 8, 0),
(11, 'ZahraaSayed', '85aed1989658b6c6ae011fa81a4e456d', 33331111, 'zahraa123alsayed@gmail.com', '1672122683defaultprofile.jpg', 9, 0),
(12, 'Fatima', '827ccb0eea8a706c4c34a16891f84e7b', 39394141, 'fatima123@gmail.com', '1672122683defaultprofile.jpg', 10, 0);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `booking`
--
ALTER TABLE `booking`
  ADD PRIMARY KEY (`id`),
  ADD KEY `booking_kashta_relation` (`kashta_id`),
  ADD KEY `booking_user` (`user_id`);

--
-- Indexes for table `booking_services`
--
ALTER TABLE `booking_services`
  ADD PRIMARY KEY (`id`),
  ADD KEY `booking` (`booking_id`),
  ADD KEY `service` (`service_id`);

--
-- Indexes for table `comments`
--
ALTER TABLE `comments`
  ADD PRIMARY KEY (`id`),
  ADD KEY `comments_kashta` (`kashta_id`),
  ADD KEY `comments_customer` (`user_id`);

--
-- Indexes for table `customer`
--
ALTER TABLE `customer`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `kashta`
--
ALTER TABLE `kashta`
  ADD PRIMARY KEY (`id`),
  ADD KEY `kashta_admin_relation` (`admin_id`) USING BTREE;

--
-- Indexes for table `kashta_images`
--
ALTER TABLE `kashta_images`
  ADD PRIMARY KEY (`id`),
  ADD KEY `images_kashta_relation` (`kashta_id`);

--
-- Indexes for table `kashta_services`
--
ALTER TABLE `kashta_services`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `rating`
--
ALTER TABLE `rating`
  ADD PRIMARY KEY (`id`),
  ADD KEY `rating_customer_relation` (`user_id`),
  ADD KEY `rating_kashta_relation` (`kashta_id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD KEY `user_customer_relation` (`customer_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `booking`
--
ALTER TABLE `booking`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;

--
-- AUTO_INCREMENT for table `booking_services`
--
ALTER TABLE `booking_services`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=27;

--
-- AUTO_INCREMENT for table `comments`
--
ALTER TABLE `comments`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;

--
-- AUTO_INCREMENT for table `customer`
--
ALTER TABLE `customer`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `kashta`
--
ALTER TABLE `kashta`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=25;

--
-- AUTO_INCREMENT for table `kashta_images`
--
ALTER TABLE `kashta_images`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=60;

--
-- AUTO_INCREMENT for table `kashta_services`
--
ALTER TABLE `kashta_services`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `rating`
--
ALTER TABLE `rating`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `comments`
--
ALTER TABLE `comments`
  ADD CONSTRAINT `comments_kashta` FOREIGN KEY (`kashta_id`) REFERENCES `kashta` (`id`),
  ADD CONSTRAINT `comments_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`);

--
-- Constraints for table `kashta`
--
ALTER TABLE `kashta`
  ADD CONSTRAINT `kashta_admin_relation` FOREIGN KEY (`admin_id`) REFERENCES `users` (`id`);

--
-- Constraints for table `rating`
--
ALTER TABLE `rating`
  ADD CONSTRAINT `rating_customer_relation` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`),
  ADD CONSTRAINT `rating_kashta_relation` FOREIGN KEY (`kashta_id`) REFERENCES `kashta` (`id`);

--
-- Constraints for table `users`
--
ALTER TABLE `users`
  ADD CONSTRAINT `user_customer_relation` FOREIGN KEY (`customer_id`) REFERENCES `customer` (`id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
