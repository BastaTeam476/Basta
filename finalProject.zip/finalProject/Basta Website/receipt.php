<!-- <?php
echo "<pre>";
// print_r($_GET);
// print_r($_POST);
extract($_POST);
extract($_GET);
echo "</pre>";
?> 
Array
(
    [booking_id] => 3
)
Array
(
    [main_price] => 5200
    [service_description] => Array
        (
            [0] => Grilling
            [1] => Extra Chairs
            [2] => DJ
        )

    [service_price] => Array
        (
            [0] => 50
            [1] => 15
            [2] => 20
        )

    [service_icon] => Array
        (
            [0] => bbq.png
            [1] => chair.png
            [2] => dj.png
        )

    [KashtaName] => Al Saeed
    [pickedDate] => 2022-12-07
    [pickedTiming] => 5pm - 1am
    [pickedLocation] => Sakheer
    [finalPrice] => 5285 BD
    [subreserve] => Print Receipt
)
-->

<head>
	<title>
		Receipt for <?=$KashtaName?>
	</title>
	<link rel="stylesheet" href="receipt.css">
</head>

<body>
	<div style="display: flex;flex-direction: column;align-items: center;">
		<h2>
			<?=$KashtaName?> Booking #<?=$booking_id.$kashta_id?>
		</h2>
		<div style="column-count:2;">
			<div>
				<b>Date : </b> <?=$pickedDate?>
			</div>
			<div>
				<b>Timing : </b> <?=$pickedTiming?>
			</div>
			<div>
				<b>Place : </b> <?=$pickedPlace?>
			</div>
			<div>
				<b>Total Price : </b> <?=$finalPrice?>
			</div>
		</div>
		<br>
		<div>

		
			<table>

			<?php if(isset($_POST['service_icon'])){ ?>

						<?php foreach ($service_icon as $key => $value) { ?>

						<tr>
							<td class="labelcell">
								<img width="25" src="icons/<?= $value ?>" />
								<b><?=$service_description[$key]?></b>
							</td>
							<td>
								<?php
									for ($i=0; $i < 60; $i++) { 
										echo ".";
									}
								?>
							</td>
							<td>
								<?=$service_price[$key]?> BD
							</td>
						</tr>
						<?php } }?>
						<tr>
							<td class="labelcell">
								<div style="width:25px;"></div>
								<b>Base Price</b>
							</td>
							<td>
								<?php
									for ($i=0; $i < 60; $i++) { 
										echo ".";
									}
								?>
							</td>
							<td>
								<?=$main_price?> BD
							</td>
						</tr>
						<tr>
							<td class="labelcell">
								<div style="width:25px;"></div>
								<b>Total Price</b>
							</td>
							<td>
								<?php
									for ($i=0; $i < 60; $i++) { 
										echo ".";
									}
								?>
							</td>
							<td>
								<b><?=$finalPrice?></b>
							</td>
						</tr>
			</table>
		</div>

		<br />
		<div style="text-align:center;">
			<b>Thank you for booking with us!</b>
			<br />
			<b>Contact 17000000 for any enquiries.</b>
		</div>
		<div class="noprintsection" style="text-align:center;">
			<div class="d-flex gap-2">
				<button onclick="window.close()">Close</button>
				<button onclick="window.print()">Print</button>
			</div>

		</div>
	</div>
	<script>
	// function print_receipt(){

	// }
	// setTimeout(() => {
	// window.print();
	// window.close();
	// }, 350);
	</script>
</body>