<?php
include_once('connection.php');
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}
header('Content-type: application/json');
$msg = "No data received.";
$comments = [];
try { 
$post = file_get_contents('php://input');
$d = json_decode($post,true);
$msg = "No data received.";
 if(isset($d['comment'])){

	$errors = [];

	if(!preg_match("/^[a-zA-Z ]+$/i", $d['comment'])){
		$errors[]="Comment may only contain letters and spaces.";
	}

	if(count($errors)){
		$msg = "";
		foreach ($errors as $key => $value) {
			$msg.= "$value";
		}
		http_response_code(500);
	}else{
		$db->beginTransaction();

		$stmt = $db->prepare("
		INSERT INTO `comments` 
		(`kashta_id`,	`user_id`,	`description`) VALUES 
		(:kashta_id,	:user_id ,	:description);");

		$stmt->bindParam(':kashta_id',$d['kashta_id']);
		$stmt->bindParam(':user_id', $_SESSION['login_user']['id']);
		$stmt->bindParam(':description',$d['comment']);
		
		$stmt->execute();
		$db->commit();
		$msg = "Comment added.";

		$q = $db->prepare('select comments.*, users.username as `name`, users.profile_image as `img` from comments left join users on users.id = comments.user_id where kashta_id = :kashta_id ORDER BY `comments`.`id` DESC');
		$q->bindParam(':kashta_id', $d['kashta_id']);
		$q->execute();

		$q->setFetchMode(PDO::FETCH_ASSOC);
		$comments = $q->fetchAll();
	}
}
} catch(Exception $e) {
	http_response_code(500);
	$msg = $e->getMessage();
}
echo json_encode(array("message"=>$msg,"comments"=>$comments));